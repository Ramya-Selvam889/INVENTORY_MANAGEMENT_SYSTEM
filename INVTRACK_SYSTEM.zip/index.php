<?php
require_once 'includes/db.php';
if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }

$error = '';
$tab   = $_GET['tab'] ?? 'admin';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'login') {
    $tab      = $_POST['tab'];
    $username = trim($_POST['username']);
    $password = md5(trim($_POST['password']));

    if ($tab === 'admin') {
        $st = $conn->prepare("SELECT * FROM admin WHERE username=? AND password=?");
        $st->bind_param("ss", $username, $password);
        $st->execute();
        $res = $st->get_result()->fetch_assoc();
        if ($res) {
            $_SESSION['user_id']  = $res['id'];
            $_SESSION['role']     = 'admin';
            $_SESSION['name']     = $res['name'];
            $_SESSION['username'] = $res['username'];
            header('Location: dashboard.php'); exit;
        } else { $error = 'Invalid admin credentials.'; }

    } elseif ($tab === 'supplier') {
        $st = $conn->prepare("SELECT * FROM suppliers WHERE username=? AND password=?");
        $st->bind_param("ss", $username, $password);
        $st->execute();
        $res = $st->get_result()->fetch_assoc();
        if (!$res)                         { $error = 'Account not found. Please register.'; }
        elseif ($res['status']==='pending') { $error = '⏳ Your account is awaiting admin approval.'; }
        elseif ($res['status']==='rejected'){ $error = '❌ Your account was rejected by admin.'; }
        else {
            $_SESSION['user_id']     = $res['id'];
            $_SESSION['role']        = 'supplier';
            $_SESSION['name']        = $res['company_name'];
            $_SESSION['username']    = $res['username'];
            $_SESSION['supplier_id'] = $res['id'];
            header('Location: dashboard.php'); exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>InvTrack — Login</title>
<style>
/* ── BRIGHT THEME LOGIN PAGE ── */
*{margin:0;padding:0;box-sizing:border-box;}
body{
  background:#f0f4ff;
  color:#1e1b4b;
  font-family:'Times New Roman',Times,serif;
  min-height:100vh;
  display:flex; align-items:center; justify-content:center;
}
body::before{
  content:''; position:fixed; inset:0;
  background-image:
    linear-gradient(rgba(79,70,229,.05) 1px,transparent 1px),
    linear-gradient(90deg,rgba(79,70,229,.05) 1px,transparent 1px);
  background-size:40px 40px; pointer-events:none;
}

/* ── Split wrapper ── */
.auth-wrap{
  display:flex; width:880px; max-width:98vw;
  min-height:540px; border-radius:22px; overflow:hidden;
  border:1.5px solid #c7d2fe;
  box-shadow:0 12px 50px rgba(79,70,229,.2);
  position:relative; z-index:1;
}

/* ── LEFT panel (blue) ── */
.auth-left{
  flex:1;
  background:#4f46e5;
  padding:48px 38px;
  display:flex; flex-direction:column; justify-content:center;
}
.auth-logo{
  font-size:2rem; font-weight:900; color:#ffffff;
  letter-spacing:-1px; font-style:italic; margin-bottom:6px;
}
.auth-logo span{color:#c7d2fe;}
.auth-tagline{
  font-size:.84rem; color:rgba(255,255,255,.75);
  margin-bottom:36px; line-height:1.65;
}
.who-title{
  font-size:.72rem; text-transform:uppercase; letter-spacing:.12em;
  color:#c7d2fe; font-weight:700; margin-bottom:14px;
}
.role-info{
  display:flex; align-items:flex-start; gap:12px; margin-bottom:14px;
}
.role-icon{
  width:34px; height:34px; border-radius:8px;
  background:rgba(255,255,255,.2);
  display:flex; align-items:center; justify-content:center;
  font-size:1rem; flex-shrink:0;
}
.role-text{ font-size:.8rem; color:rgba(255,255,255,.8); line-height:1.55; }
.role-text strong{ color:#ffffff; display:block; font-size:.83rem; margin-bottom:2px; }

/* Demo box */
.demo-box{
  background:rgba(255,255,255,.14);
  border:1px solid rgba(255,255,255,.3);
  border-radius:10px; padding:14px 16px; margin-top:28px;
}
.demo-box h4{
  font-size:.7rem; text-transform:uppercase; letter-spacing:.1em;
  color:#c7d2fe; font-weight:700; margin-bottom:10px;
}
.demo-row{ font-size:.78rem; color:rgba(255,255,255,.75); margin-bottom:5px; }
.demo-row code{
  color:#ffffff; background:rgba(255,255,255,.2);
  padding:1px 7px; border-radius:4px; font-family:monospace;
}

/* ── RIGHT panel (white) ── */
.auth-right{
  width:380px;
  background:#ffffff;
  padding:44px 36px;
  display:flex; flex-direction:column; justify-content:center;
}

/* Tabs */
.tab-row{
  display:flex; gap:8px;
  background:#f0f4ff; padding:5px;
  border-radius:11px; margin-bottom:24px;
  border:1px solid #c7d2fe;
}
.tab-btn{
  flex:1; padding:9px; text-align:center; border-radius:7px;
  cursor:pointer; font-size:.83rem; font-weight:700;
  color:#6b7280; transition:all .2s; border:none;
  font-family:'Times New Roman',serif; background:transparent;
}
.tab-btn.active{
  background:#4f46e5; color:#ffffff;
  box-shadow:0 2px 10px rgba(79,70,229,.3);
}

.auth-title{
  font-size:1.4rem; font-weight:800;
  margin-bottom:22px; font-style:italic;
  color:#1e1b4b;
}

/* Form fields */
.fg{ display:flex; flex-direction:column; gap:6px; margin-bottom:15px; }
.fg label{
  font-size:.72rem; text-transform:uppercase;
  letter-spacing:.1em; color:#4f46e5; font-weight:700;
}
.fg input{
  background:#f5f3ff; border:1.5px solid #c7d2fe;
  color:#1e1b4b; padding:11px 14px;
  border-radius:9px; font-family:'Times New Roman',serif;
  font-size:.9rem; outline:none; transition:border-color .2s, box-shadow .2s;
  width:100%;
}
.fg input:focus{
  border-color:#4f46e5;
  box-shadow:0 0 0 3px rgba(79,70,229,.12);
  background:#ffffff;
}

/* Login button */
.btn-auth{
  width:100%; padding:13px;
  background:#4f46e5;
  border:none; border-radius:10px;
  color:#ffffff; font-family:'Times New Roman',serif;
  font-size:1rem; font-weight:700;
  cursor:pointer; transition:all .2s;
  box-shadow:0 4px 14px rgba(79,70,229,.3);
  letter-spacing:.5px;
}
.btn-auth:hover{
  background:#4338ca;
  transform:translateY(-2px);
  box-shadow:0 8px 24px rgba(79,70,229,.4);
}

/* Error */
.auth-error{
  background:#fee2e2; border:1px solid #fca5a5;
  color:#991b1b; border-radius:8px;
  padding:10px 13px; font-size:.82rem; margin-bottom:14px;
}

/* Register link */
.register-link{
  text-align:center; font-size:.82rem;
  color:#6b7280; margin-top:16px;
}
.register-link a{
  color:#4f46e5; text-decoration:none; font-weight:700;
}
.register-link a:hover{ text-decoration:underline; }

/* Supplier note */
.supplier-note{
  background:#fef3c7; border:1px solid #fcd34d;
  color:#92400e; border-radius:8px;
  padding:10px 13px; font-size:.8rem;
  margin-top:14px; line-height:1.6;
}
</style>
</head>
<body>
<div class="auth-wrap">

  <!-- LEFT: Info panel -->
  <div class="auth-left">
    <div class="auth-logo">Inv<span>Track</span></div>
    <div class="auth-tagline">
      Inventory Management System<br>
  
    </div>

    <div class="who-title">Who can login?</div>

    <div class="role-info">
      <div class="role-icon">👑</div>
      <div class="role-text">
        <strong>Admin</strong>
        Fixed credentials. Direct login. Can manage everything and approve suppliers.
      </div>
    </div>
    <div class="role-info">
      <div class="role-icon">🏭</div>
      <div class="role-text">
        <strong>Supplier</strong>
        Existing suppliers login directly. New suppliers must register and wait for admin approval.
      </div>
    </div>

    <div class="demo-box">
      <h4>Demo Credentials</h4>
      <div class="demo-row">Admin: <code>admin</code> / <code>admin123</code></div>
      <div class="demo-row">Supplier: <code>techsup</code> / <code>pass123</code></div>
    </div>
  </div>

  <!-- RIGHT: Login form -->
  <div class="auth-right">
    <div class="tab-row">
      <button class="tab-btn <?= $tab==='admin'?'active':'' ?>" onclick="switchTab('admin')">
        👑 Admin
      </button>
      <button class="tab-btn <?= $tab==='supplier'?'active':'' ?>" onclick="switchTab('supplier')">
        🏭 Supplier
      </button>
    </div>

    <div class="auth-title" id="login-title">
      <?= $tab==='admin' ? 'Admin Login' : 'Supplier Login' ?>
    </div>

    <?php if($error): ?>
    <div class="auth-error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="index.php">
      <input type="hidden" name="action" value="login"/>
      <input type="hidden" name="tab" id="tab-input" value="<?= htmlspecialchars($tab) ?>"/>

      <div class="fg">
        <label>Username</label>
        <input type="text" name="username" placeholder="Enter your username"
               required autocomplete="username"/>
      </div>
      <div class="fg">
        <label>Password</label>
        <input type="password" name="password" placeholder="Enter your password"
               required autocomplete="current-password"/>
      </div>

      <button type="submit" class="btn-auth">Login →</button>
    </form>

    <div class="register-link" id="reg-link"
         style="<?= $tab==='supplier'?'display:block':'display:none' ?>">
      New supplier? <a href="register.php">Register here</a>
    </div>

    <div class="supplier-note" id="sup-note"
         style="<?= $tab==='supplier'?'display:block':'display:none' ?>">
      ⚠ New suppliers must <strong>register first</strong> and wait for admin approval before they can login.
    </div>
  </div>

</div>

<script>
function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach((b,i) =>
    b.classList.toggle('active', ['admin','supplier'][i] === tab));
  document.getElementById('tab-input').value = tab;
  document.getElementById('login-title').textContent =
    tab === 'admin' ? 'Admin Login' : 'Supplier Login';
  document.getElementById('reg-link').style.display  = tab==='supplier' ? 'block' : 'none';
  document.getElementById('sup-note').style.display  = tab==='supplier' ? 'block' : 'none';
}
</script>
</body>
</html>