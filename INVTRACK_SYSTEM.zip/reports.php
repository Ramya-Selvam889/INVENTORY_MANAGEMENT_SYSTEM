<?php
require_once 'includes/db.php';
requireLogin();
$role = $_SESSION['role'];

// ── CSV Export ──────────────────────────────────────────────────────────────
if (isset($_GET['export'])) {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="inventory_report_'.date('Y-m-d').'.csv"');
    $out = fopen('php://output','w');
    fputcsv($out,['Product Code','Name','Category','Stock','Unit Price','Total Value','Status']);

    if ($role === 'admin') {
        $rows = $conn->query("SELECT p.product_code,p.name,c.name as cat,p.stock,p.price,p.min_threshold FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.stock*p.price DESC");
    } else {
        $sid=(int)$_SESSION['supplier_id'];
        $rows = $conn->query("SELECT p.product_code,p.name,c.name as cat,p.stock,p.price,p.min_threshold FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.supplier_id=$sid ORDER BY p.stock*p.price DESC");
    }
    while($r=$rows->fetch_assoc()){
        fputcsv($out,[$r['product_code'],$r['name'],$r['cat'],$r['stock'],$r['price'],$r['stock']*$r['price'],$r['stock']<=$r['min_threshold']?'Low Stock':'In Stock']);
    }
    fclose($out); exit;
}

// ═══════════════════════════════════════════════════════════════
//  ADMIN — all data
// ═══════════════════════════════════════════════════════════════
if ($role === 'admin') {
    $totalProducts = $conn->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
    $totalStock    = $conn->query("SELECT SUM(stock) as s FROM products")->fetch_assoc()['s'] ?? 0;
    $totalValue    = $conn->query("SELECT SUM(stock*price) as v FROM products")->fetch_assoc()['v'] ?? 0;
    $lowCount      = $conn->query("SELECT COUNT(*) as c FROM products WHERE stock<=min_threshold")->fetch_assoc()['c'];
    $catCount      = $conn->query("SELECT COUNT(DISTINCT category_id) as c FROM products")->fetch_assoc()['c'];
    $supCount      = $conn->query("SELECT COUNT(*) as c FROM suppliers WHERE status='approved'")->fetch_assoc()['c'];
    $totalOrders   = $conn->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
    $del = $conn->query("SELECT COUNT(*) as c, SUM(quantity*unit_price) as v FROM orders WHERE status='Delivered'")->fetch_assoc();
    $pending   = $conn->query("SELECT COUNT(*) as c FROM orders WHERE status='Pending'")->fetch_assoc()['c'];
    $cancelled = $conn->query("SELECT COUNT(*) as c FROM orders WHERE status='Cancelled'")->fetch_assoc()['c'];
    $topProducts = $conn->query("SELECT p.product_code,p.name,c.name as cat,p.stock,p.price,p.min_threshold FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.stock*p.price DESC");
    $supCount_label = $supCount;

// ═══════════════════════════════════════════════════════════════
//  SUPPLIER — only their own data
// ═══════════════════════════════════════════════════════════════
} else {
    $sid = (int)$_SESSION['supplier_id'];
    $totalProducts = $conn->query("SELECT COUNT(*) as c FROM products WHERE supplier_id=$sid")->fetch_assoc()['c'];
    $totalStock    = $conn->query("SELECT SUM(stock) as s FROM products WHERE supplier_id=$sid")->fetch_assoc()['s'] ?? 0;
    $totalValue    = $conn->query("SELECT SUM(stock*price) as v FROM products WHERE supplier_id=$sid")->fetch_assoc()['v'] ?? 0;
    $lowCount      = $conn->query("SELECT COUNT(*) as c FROM products WHERE supplier_id=$sid AND stock<=min_threshold")->fetch_assoc()['c'];
    $catCount      = $conn->query("SELECT COUNT(DISTINCT category_id) as c FROM products WHERE supplier_id=$sid")->fetch_assoc()['c'];
    $totalOrders   = $conn->query("SELECT COUNT(*) as c FROM orders WHERE supplier_id=$sid")->fetch_assoc()['c'];
    $del = $conn->query("SELECT COUNT(*) as c, SUM(quantity*unit_price) as v FROM orders WHERE supplier_id=$sid AND status='Delivered'")->fetch_assoc();
    $pending   = $conn->query("SELECT COUNT(*) as c FROM orders WHERE supplier_id=$sid AND status='Pending'")->fetch_assoc()['c'];
    $cancelled = $conn->query("SELECT COUNT(*) as c FROM orders WHERE supplier_id=$sid AND status='Cancelled'")->fetch_assoc()['c'];
    $topProducts = $conn->query("SELECT p.product_code,p.name,c.name as cat,p.stock,p.price,p.min_threshold FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.supplier_id=$sid ORDER BY p.stock*p.price DESC");
    $supInfo = $conn->query("SELECT company_name,supplier_code FROM suppliers WHERE id=$sid")->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>InvTrack — <?= $role==='admin'?'Reports':'My Reports' ?></title>
<link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>
<div id="main">
  <div class="topbar">
    <h1><?= $role==='admin'?'Reports':'My Reports' ?></h1>
    <div class="topbar-badges">
      <span class="chip chip-<?= $role ?>"><?= $role==='admin'?'👑 Admin':'🏭 Supplier' ?></span>
      <span class="chip chip-live">🟢 Live</span>
    </div>
  </div>
  <div class="content">

    <!-- Supplier context notice -->
    <?php if($role==='supplier' && isset($supInfo)): ?>
    <div style="background:#eef2ff;border:1.5px solid #c7d2fe;border-radius:12px;padding:14px 20px;margin-bottom:20px;display:flex;align-items:center;gap:12px">
      <div style="width:36px;height:36px;border-radius:50%;background:#4f46e5;display:flex;align-items:center;justify-content:center;font-weight:900;color:#fff;font-size:1rem;flex-shrink:0"><?= strtoupper($supInfo['company_name'][0]) ?></div>
      <div>
        <div style="font-weight:800;color:#4f46e5;font-style:italic"><?= htmlspecialchars($supInfo['company_name']) ?> — My Report</div>
        <div style="font-size:.76rem;color:#6b7280">Showing data for your account only (<?= htmlspecialchars($supInfo['supplier_code']) ?>)</div>
      </div>
      <a href="reports.php?export=1" class="btn btn-primary btn-sm" style="margin-left:auto">⬇ Export My CSV</a>
    </div>
    <?php endif; ?>

    <!-- Summary panels -->
    <div class="charts-grid">
      <div class="chart-box">
        <div class="chart-title">📦 <?= $role==='supplier'?'My ':''; ?>Inventory Summary</div>
        <div style="font-size:.88rem;line-height:2.2;color:#1e1b4b">
          <div><?= $role==='supplier'?'My Products':'Total Products' ?>: <strong style="color:#4f46e5"><?= $totalProducts ?></strong></div>
          <div><?= $role==='supplier'?'My Stock Units':'Total Stock Units' ?>: <strong><?= number_format($totalStock) ?></strong></div>
          <div><?= $role==='supplier'?'My Inventory Value':'Inventory Value' ?>: <strong>₹<?= number_format($totalValue,2) ?></strong></div>
          <div>Low Stock Items: <strong style="color:#dc2626"><?= $lowCount ?></strong></div>
          <div>Categories: <strong><?= $catCount ?></strong></div>
          <?php if($role==='admin'): ?><div>Active Suppliers: <strong><?= $supCount_label ?></strong></div><?php endif; ?>
        </div>
      </div>
      <div class="chart-box">
        <div class="chart-title">💰 <?= $role==='supplier'?'My ':''; ?>Financial Overview</div>
        <div style="font-size:.88rem;line-height:2.2;color:#1e1b4b">
          <div><?= $role==='supplier'?'My Stock Value':'Total Inventory Value' ?>: <strong style="color:#4f46e5">₹<?= number_format($totalValue,2) ?></strong></div>
          <div><?= $role==='supplier'?'My Total Orders':'Total Orders' ?>: <strong><?= $totalOrders ?></strong></div>
          <div>Delivered Orders: <strong style="color:#16a34a"><?= $del['c'] ?></strong></div>
          <div>Total Sales Value: <strong>₹<?= number_format($del['v']??0,2) ?></strong></div>
          <div>Pending Orders: <strong style="color:#7c3aed"><?= $pending ?></strong></div>
          <div>Cancelled Orders: <strong style="color:#dc2626"><?= $cancelled ?></strong></div>
        </div>
      </div>
    </div>

    <!-- Products table -->
    <div class="card">
      <div class="card-header">
        <span class="card-title"><?= $role==='supplier'?'My Products by Stock Value':'Top Products by Stock Value' ?></span>
        <?php if($role==='admin'): ?>
        <a href="reports.php?export=1" class="btn btn-outline btn-sm">⬇ Export CSV</a>
        <?php endif; ?>
      </div>
      <table>
        <thead><tr><th>Code</th><th>Product</th><th>Category</th><th>Stock</th><th>Unit Price</th><th>Total Value</th><th>Status</th></tr></thead>
        <tbody>
        <?php if($totalProducts==0): ?>
          <tr><td colspan="7" style="text-align:center;color:#6b7280;padding:30px">No products found for your account.</td></tr>
        <?php else: while($p=$topProducts->fetch_assoc()): $low=$p['stock']<=$p['min_threshold']; ?>
        <tr>
          <td style="color:#6b7280;font-size:.76rem"><?= $p['product_code'] ?></td>
          <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
          <td><?= htmlspecialchars($p['cat']??'—') ?></td>
          <td><?= $p['stock'] ?></td>
          <td>₹<?= number_format($p['price'],2) ?></td>
          <td><strong>₹<?= number_format($p['stock']*$p['price'],2) ?></strong></td>
          <td><span class="tag tag-<?= $low?'low':'ok' ?>"><?= $low?'Low Stock':'In Stock' ?></span></td>
        </tr>
        <?php endwhile; endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</body>
</html>