<?php
require_once 'includes/db.php';
requireLogin();
$role = $_SESSION['role'];
$canChangeStatus = ($role === 'admin');
$canPlaceOrder   = ($role === 'admin' || $role === 'supplier');

$msg = '';

// ─── Handle actions ───
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'add' && $canPlaceOrder) {
        $pid   = (int)$_POST['product_id'];
        $qty   = (int)$_POST['quantity'];
        $price = (float)$_POST['unit_price'];
        $supId = (int)$_POST['supplier_id'];
        $status= $_POST['status'];
        $date  = $_POST['order_date'];

        $res = $conn->query("SELECT COUNT(*) as c FROM orders");
        $cnt = $res->fetch_assoc()['c'] + 1;
        $code = 'ORD' . str_pad($cnt, 3, '0', STR_PAD_LEFT);

        $stmt = $conn->prepare("INSERT INTO orders (order_code,product_id,quantity,unit_price,supplier_id,status,order_date) VALUES (?,?,?,?,?,?,?)");
        $stmt->bind_param("siidiss",$code,$pid,$qty,$price,$supId,$status,$date);
        $stmt->execute();

        if ($status === 'Delivered') {
            $conn->query("UPDATE products SET stock=stock+$qty WHERE id=$pid");
        }
        $msg = 'success:Order placed successfully!';

    } elseif ($action === 'update_status' && $canChangeStatus) {
        $oid    = (int)$_POST['order_id'];
        $newSt  = $_POST['new_status'];
        $oldRes = $conn->query("SELECT status,product_id,quantity FROM orders WHERE id=$oid")->fetch_assoc();
        $conn->query("UPDATE orders SET status='$newSt' WHERE id=$oid");

        // Adjust stock
        if ($oldRes['status']==='Delivered' && $newSt!=='Delivered') {
            $conn->query("UPDATE products SET stock=stock-{$oldRes['quantity']} WHERE id={$oldRes['product_id']}");
        } elseif ($oldRes['status']!=='Delivered' && $newSt==='Delivered') {
            $conn->query("UPDATE products SET stock=stock+{$oldRes['quantity']} WHERE id={$oldRes['product_id']}");
        }
        $msg = 'success:Order status updated!';

    } elseif ($action === 'delete' && $canChangeStatus) {
        $oid = (int)$_POST['order_id'];
        $conn->query("DELETE FROM orders WHERE id=$oid");
        $msg = 'success:Order deleted.';
    }
}

// ─── Fetch ───
$search   = trim($_GET['search'] ?? '');
$statusF  = trim($_GET['status'] ?? '');
$where    = "WHERE 1=1";
if ($search)  $where .= " AND (o.order_code LIKE '%".mysqli_real_escape_string($conn,$search)."%' OR p.name LIKE '%".mysqli_real_escape_string($conn,$search)."%')";
if ($statusF) $where .= " AND o.status='".mysqli_real_escape_string($conn,$statusF)."'";
if ($role === 'supplier') $where .= " AND o.supplier_id=".(int)$_SESSION['supplier_id'];

$orders = $conn->query("
    SELECT o.*, p.name as product_name, s.company_name as supplier_name
    FROM orders o
    LEFT JOIN products p ON o.product_id=p.id
    LEFT JOIN suppliers s ON o.supplier_id=s.id
    $where ORDER BY o.created_at DESC
");

$products  = $conn->query("SELECT id,name,price,supplier_id FROM products ORDER BY name");
$suppliers = $conn->query("SELECT id,company_name FROM suppliers WHERE status='approved'");
$prods_arr = []; $pR=$conn->query("SELECT p.id,p.name,p.price,s.id as sid,s.company_name FROM products p LEFT JOIN suppliers s ON p.supplier_id=s.id");
while($r=$pR->fetch_assoc()) $prods_arr[] = $r;
$sups_arr  = []; $sR=$conn->query("SELECT id,company_name FROM suppliers WHERE status='approved'");
while($r=$sR->fetch_assoc()) $sups_arr[] = $r;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>InvTrack — Orders</title>
<link rel="stylesheet" href="css/style.css"/>
<style>
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:300;align-items:center;justify-content:center;backdrop-filter:blur(5px);}
.modal-overlay.open{display:flex;}
.modal{background:var(--surface);border:1px solid var(--border);border-radius:18px;padding:30px;width:520px;max-width:95vw;max-height:90vh;overflow-y:auto;box-shadow:0 0 60px var(--glow);}
.modal-title{font-size:1.1rem;font-weight:800;font-style:italic;margin-bottom:20px;}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:13px;}
</style>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div id="main">
  <div class="topbar">
    <h1>Orders</h1>
    <div class="topbar-badges">
      <span class="chip chip-<?= $role ?>"><?= $role==='admin'?'👑 Admin':($role==='supplier'?'🏭 Supplier':'👤 User') ?></span>
      <span class="chip chip-live">🟢 Live</span>
    </div>
  </div>

  <div class="content">
    <?php if($msg): list($t,$m)=explode(':',$msg,2); ?>
    <div class="alert alert-<?= $t==='success'?'success':'danger' ?>"><?= htmlspecialchars($m) ?></div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header">
        <form method="GET" action="orders.php" style="display:flex;gap:9px;flex-wrap:wrap;align-items:center">
          <div class="search-box">🔍<input type="text" name="search" placeholder="Search orders..." value="<?= htmlspecialchars($search) ?>"/></div>
          <select name="status" class="filter-sel" onchange="this.form.submit()">
            <option value="">All Status</option>
            <option value="Pending" <?= $statusF==='Pending'?'selected':'' ?>>Pending</option>
            <option value="Delivered" <?= $statusF==='Delivered'?'selected':'' ?>>Delivered</option>
            <option value="Cancelled" <?= $statusF==='Cancelled'?'selected':'' ?>>Cancelled</option>
          </select>
          <?php if($search||$statusF): ?><a href="orders.php" class="btn btn-outline btn-sm">✕ Clear</a><?php endif; ?>
        </form>
        <?php if($canPlaceOrder): ?><button class="btn btn-primary" onclick="openModal()">+ Place Order</button><?php endif; ?>
      </div>
      <table>
        <thead><tr><th>Order ID</th><th>Product</th><th>Qty</th><th>Unit Price</th><th>Total</th><th>Supplier</th><th>Status</th><th>Date</th><?php if($canChangeStatus): ?><th>Actions</th><?php endif; ?></tr></thead>
        <tbody>
        <?php while($o=$orders->fetch_assoc()): $sc=strtolower($o['status']); ?>
        <tr>
          <td style="color:var(--accent3)"><?= $o['order_code'] ?></td>
          <td><?= htmlspecialchars($o['product_name']) ?></td>
          <td><?= $o['quantity'] ?></td>
          <td>₹<?= number_format($o['unit_price'],2) ?></td>
          <td><strong>₹<?= number_format($o['quantity']*$o['unit_price'],2) ?></strong></td>
          <td><?= htmlspecialchars($o['supplier_name']) ?></td>
          <td><span class="tag tag-<?= $sc ?>"><?= $o['status'] ?></span></td>
          <td style="color:var(--muted)"><?= $o['order_date'] ?></td>
          <?php if($canChangeStatus): ?>
          <td>
            <form method="POST" style="display:inline">
              <input type="hidden" name="action" value="update_status"/>
              <input type="hidden" name="order_id" value="<?= $o['id'] ?>"/>
              <select name="new_status" class="filter-sel" style="padding:4px 8px;font-size:.73rem" onchange="this.form.submit()">
                <option <?= $o['status']==='Pending'?'selected':'' ?>>Pending</option>
                <option <?= $o['status']==='Delivered'?'selected':'' ?>>Delivered</option>
                <option <?= $o['status']==='Cancelled'?'selected':'' ?>>Cancelled</option>
              </select>
            </form>
            <form method="POST" style="display:inline" onsubmit="return confirm('Delete order?')">
              <input type="hidden" name="action" value="delete"/>
              <input type="hidden" name="order_id" value="<?= $o['id'] ?>"/>
              <button type="submit" class="btn btn-danger btn-sm">🗑</button>
            </form>
          </td>
          <?php endif; ?>
        </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php if($canPlaceOrder): ?>
<div class="modal-overlay" id="order-modal">
  <div class="modal">
    <div class="modal-title">Place New Order</div>
    <form method="POST" action="orders.php">
      <input type="hidden" name="action" value="add"/>
      <div class="form-grid">
        <div class="fg full">
          <label>Product *</label>
          <select name="product_id" id="f-product" onchange="fillSupplier()" required>
            <option value="">Select product...</option>
            <?php foreach($prods_arr as $p): ?>
            <option value="<?= $p['id'] ?>" data-price="<?= $p['price'] ?>" data-sid="<?= $p['sid'] ?>"><?= htmlspecialchars($p['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="fg"><label>Quantity *</label><input type="number" name="quantity" id="f-qty" min="1" required/></div>
        <div class="fg"><label>Unit Price (₹)</label><input type="number" name="unit_price" id="f-price" step="0.01" min="0"/></div>
        <div class="fg">
          <label>Supplier</label>
          <select name="supplier_id" id="f-sup">
            <option value="">Auto</option>
            <?php foreach($sups_arr as $s): ?>
            <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['company_name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="fg"><label>Order Date</label><input type="date" name="order_date" id="f-date" value="<?= date('Y-m-d') ?>"/></div>
        <div class="fg">
          <label>Status</label>
          <select name="status">
            <option>Pending</option><option>Delivered</option><option>Cancelled</option>
          </select>
        </div>
      </div>
      <div class="form-actions">
        <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">Place Order</button>
      </div>
    </form>
  </div>
</div>
<script>
const supsData = <?= json_encode(array_column($sups_arr,'company_name','id')) ?>;
function fillSupplier(){
  const opt=document.getElementById('f-product').selectedOptions[0];
  if(opt){document.getElementById('f-price').value=opt.dataset.price;const sid=opt.dataset.sid;if(sid)document.getElementById('f-sup').value=sid;}
}
function openModal(){document.getElementById('order-modal').classList.add('open');}
function closeModal(){document.getElementById('order-modal').classList.remove('open');}
document.getElementById('order-modal').addEventListener('click',e=>{if(e.target===document.getElementById('order-modal'))closeModal();});
</script>
<?php endif; ?>
</body>
</html>