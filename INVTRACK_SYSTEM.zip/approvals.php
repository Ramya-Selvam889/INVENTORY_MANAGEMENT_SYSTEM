<?php
require_once 'includes/db.php';
requireLogin('admin');

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)$_POST['supplier_id'];
    $action = $_POST['action'];
    if ($action === 'approve') {
        $conn->query("UPDATE suppliers SET status='approved' WHERE id=$id");
        $msg = 'success:Supplier approved! They can now login.';
    } elseif ($action === 'reject') {
        $conn->query("UPDATE suppliers SET status='rejected' WHERE id=$id");
        $msg = 'success:Supplier rejected.';
    } elseif ($action === 'revoke') {
        $conn->query("UPDATE suppliers SET status='rejected' WHERE id=$id");
        $msg = 'success:Supplier access revoked.';
    }
}

$pending  = $conn->query("SELECT * FROM suppliers WHERE status='pending' ORDER BY created_at DESC");
$approved = $conn->query("SELECT *, (SELECT COUNT(*) FROM products WHERE supplier_id=suppliers.id) as pc FROM suppliers WHERE status='approved' ORDER BY id");
$rejected = $conn->query("SELECT * FROM suppliers WHERE status='rejected' ORDER BY id");
$pendingCount = $pending->num_rows;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>InvTrack — Approvals</title>
<link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>
<div id="main">
  <div class="topbar">
    <h1>Supplier Approvals</h1>
    <div class="topbar-badges">
      <span class="chip chip-admin">👑 Admin</span>
      <?php if($pendingCount>0): ?><span class="chip chip-low">⏳ <?= $pendingCount ?> Pending</span><?php endif; ?>
      <span class="chip chip-live">🟢 Live</span>
    </div>
  </div>
  <div class="content">
    <?php if($msg): list($t,$m)=explode(':',$msg,2); ?>
    <div class="alert alert-<?= $t==='success'?'success':'danger' ?>"><?= htmlspecialchars($m) ?></div>
    <?php endif; ?>

    <!-- Pending -->
    <div class="card" style="margin-bottom:20px">
      <div class="card-header"><span class="card-title">⏳ Pending Approvals (<?= $pendingCount ?>)</span></div>
      <div style="padding:18px">
        <?php if($pendingCount === 0): ?>
        <p style="color:var(--muted);font-size:.88rem">No pending supplier registrations. ✅</p>
        <?php else: ?>
        <div class="approval-grid">
          <?php while($s=$pending->fetch_assoc()): ?>
          <div class="approval-card">
            <div class="aname"><?= htmlspecialchars($s['company_name']) ?></div>
            <div class="ameta">
              Contact: <?= htmlspecialchars($s['contact_person']) ?><br>
              Email: <?= htmlspecialchars($s['email']) ?><br>
              Phone: <?= htmlspecialchars($s['phone'] ?? '—') ?><br>
              Username: <strong><?= htmlspecialchars($s['username']) ?></strong><br>
              Registered: <?= date('d M Y', strtotime($s['created_at'])) ?>
            </div>
            <div class="approval-actions">
              <form method="POST" style="display:inline">
                <input type="hidden" name="supplier_id" value="<?= $s['id'] ?>"/>
                <input type="hidden" name="action" value="approve"/>
                <button type="submit" class="btn btn-success btn-sm">✓ Approve</button>
              </form>
              <form method="POST" style="display:inline" onsubmit="return confirm('Reject this supplier?')">
                <input type="hidden" name="supplier_id" value="<?= $s['id'] ?>"/>
                <input type="hidden" name="action" value="reject"/>
                <button type="submit" class="btn btn-danger btn-sm">✕ Reject</button>
              </form>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
        <?php endif; ?>
      </div>
    </div>

    <!-- Approved -->
    <div class="card" style="margin-bottom:20px">
      <div class="card-header"><span class="card-title">✅ Approved Suppliers</span></div>
      <table>
        <thead><tr><th>Code</th><th>Company</th><th>Contact</th><th>Username</th><th>Products</th><th>Joined</th><th>Actions</th></tr></thead>
        <tbody>
        <?php while($s=$approved->fetch_assoc()): ?>
        <tr>
          <td style="color:var(--muted);font-size:.76rem"><?= $s['supplier_code'] ?></td>
          <td><strong><?= htmlspecialchars($s['company_name']) ?></strong></td>
          <td><?= htmlspecialchars($s['contact_person'] ?? '—') ?></td>
          <td style="color:var(--accent3)"><?= htmlspecialchars($s['username'] ?? '—') ?></td>
          <td><span class="tag tag-ok"><?= $s['pc'] ?> Products</span></td>
          <td style="color:var(--muted)"><?= date('d M Y', strtotime($s['created_at'])) ?></td>
          <td>
            <form method="POST" style="display:inline" onsubmit="return confirm('Revoke access?')">
              <input type="hidden" name="supplier_id" value="<?= $s['id'] ?>"/>
              <input type="hidden" name="action" value="revoke"/>
              <button type="submit" class="btn btn-danger btn-sm">Revoke</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <!-- Rejected -->
    <div class="card">
      <div class="card-header"><span class="card-title">❌ Rejected Registrations</span></div>
      <table>
        <thead><tr><th>Company</th><th>Contact</th><th>Email</th><th>Username</th><th>Date</th><th>Actions</th></tr></thead>
        <tbody>
        <?php while($s=$rejected->fetch_assoc()): ?>
        <tr>
          <td><strong><?= htmlspecialchars($s['company_name']) ?></strong></td>
          <td><?= htmlspecialchars($s['contact_person'] ?? '—') ?></td>
          <td><?= htmlspecialchars($s['email'] ?? '—') ?></td>
          <td><?= htmlspecialchars($s['username'] ?? '—') ?></td>
          <td style="color:var(--muted)"><?= date('d M Y', strtotime($s['created_at'])) ?></td>
          <td>
            <form method="POST" style="display:inline">
              <input type="hidden" name="supplier_id" value="<?= $s['id'] ?>"/>
              <input type="hidden" name="action" value="approve"/>
              <button type="submit" class="btn btn-success btn-sm">Re-approve</button>
            </form>
          </td>
        </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>

  </div>
</div>
</body>
</html>