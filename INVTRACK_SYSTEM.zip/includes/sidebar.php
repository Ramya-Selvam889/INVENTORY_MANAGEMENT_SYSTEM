<?php
// This file is included in every page after login
$role = $_SESSION['role'];
$name = $_SESSION['name'];
$current = basename($_SERVER['PHP_SELF']);

$roleLabel = ['admin'=>'Administrator','supplier'=>'Supplier','user'=>'Regular User'];
$roleColor = ['admin'=>'var(--gold)','supplier'=>'var(--accent3)','user'=>'#34d399'];
$avatarBg  = ['admin'=>'var(--gold)','supplier'=>'var(--accent)','user'=>'var(--success)'];

// Count pending supplier approvals (admin only)
$pendingCount = 0;
if($role === 'admin') {
    $r = $conn->query("SELECT COUNT(*) as c FROM suppliers WHERE status='pending'");
    $pendingCount = $r->fetch_assoc()['c'];
}
?>
<div id="sidebar">
  <div class="logo">Inv<span>Track</span></div>
  <div class="user-chip">
    <div class="user-avatar" style="background:<?= $avatarBg[$role] ?>"><?= strtoupper($name[0]) ?></div>
    <div class="user-info">
      <div class="user-name"><?= htmlspecialchars($name) ?></div>
      <div class="user-role" style="color:<?= $roleColor[$role] ?>"><?= $roleLabel[$role] ?></div>
    </div>
  </div>
  <nav>
    <a href="dashboard.php" class="nav-item <?= $current==='dashboard.php'?'active':'' ?>">
      <span class="nav-icon">📊</span> Dashboard
    </a>
    <a href="products.php" class="nav-item <?= $current==='products.php'?'active':'' ?>">
      <span class="nav-icon">📦</span> Products
    </a>
    <a href="suppliers.php" class="nav-item <?= $current==='suppliers.php'?'active':'' ?>">
      <span class="nav-icon">🏭</span> Suppliers
    </a>
    <a href="orders.php" class="nav-item <?= $current==='orders.php'?'active':'' ?>">
      <span class="nav-icon">🛒</span> Orders
    </a>
    <a href="reports.php" class="nav-item <?= $current==='reports.php'?'active':'' ?>">
      <span class="nav-icon">📈</span> Reports
    </a>
    <?php if($role === 'admin'): ?>
    <a href="approvals.php" class="nav-item <?= $current==='approvals.php'?'active':'' ?>">
      <span class="nav-icon">✅</span> Approvals
      <?php if($pendingCount > 0): ?>
      <span class="nav-badge"><?= $pendingCount ?></span>
      <?php endif; ?>
    </a>
    <?php endif; ?>
  </nav>
  <div class="sidebar-footer">
    <a href="logout.php" class="btn-logout">⬅ Logout</a>
  </div>
</div>