<?php
// ─── Database Configuration ───
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // XAMPP default
define('DB_PASS', '');           // XAMPP default (empty)
define('DB_NAME', 'invtrack');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("<div style='font-family:Times New Roman;background:#1a0a2e;color:#f87171;padding:40px;text-align:center;min-height:100vh;display:flex;align-items:center;justify-content:center;flex-direction:column'>
        <h2>⚠ Database Connection Failed</h2>
        <p style='margin-top:12px;color:#a0aec0'>Error: " . $conn->connect_error . "</p>
        <p style='margin-top:8px;color:#a0aec0'>Make sure XAMPP MySQL is running and the database <strong>invtrack</strong> is imported.</p>
    </div>");
}

$conn->set_charset("utf8mb4");

// ─── Session Start ───
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ─── Helper: Check if logged in ───
function requireLogin($role = null) {
    if (!isset($_SESSION['user_id'])) {
        header('Location: index.php');
        exit;
    }
    if ($role && $_SESSION['role'] !== $role) {
        header('Location: dashboard.php');
        exit;
    }
}
?>