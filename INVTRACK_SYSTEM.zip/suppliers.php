<?php
require_once 'includes/db.php';
requireLogin();

$role = $_SESSION['role'];

// ───────────────────────────────────────────
//  ADMIN ONLY: Add / Edit / Delete suppliers
// ───────────────────────────────────────────
$msg = '';
if ($role === 'admin' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'add' || $action === 'edit') {
        $name    = trim($_POST['company_name']);
        $contact = trim($_POST['contact_person']);
        $email   = trim($_POST['email']);
        $phone   = trim($_POST['phone']);
        $address = trim($_POST['address']);

        if ($action === 'add') {
            $cnt  = $conn->query("SELECT COUNT(*) as c FROM suppliers")->fetch_assoc()['c'] + 1;
            $code = 'S' . str_pad($cnt, 3, '0', STR_PAD_LEFT);
            $st   = $conn->prepare("INSERT INTO suppliers (supplier_code,company_name,contact_person,email,phone,address,status) VALUES (?,?,?,?,?,?,'approved')");
            $st->bind_param("ssssss", $code, $name, $contact, $email, $phone, $address);
            $st->execute();
            $msg = 'success:Supplier added!';
        } else {
            $id = (int)$_POST['supplier_id'];
            $st = $conn->prepare("UPDATE suppliers SET company_name=?,contact_person=?,email=?,phone=?,address=? WHERE id=?");
            $st->bind_param("sssssi", $name, $contact, $email, $phone, $address, $id);
            $st->execute();
            $msg = 'success:Supplier updated!';
        }

    } elseif ($action === 'delete') {
        $id = (int)$_POST['supplier_id'];
        $conn->query("DELETE FROM suppliers WHERE id=$id");
        $msg = 'success:Supplier deleted.';
    }
}

// ───────────────────────────────────────────
//  SUPPLIER ONLY: Update their own profile
// ───────────────────────────────────────────
if ($role === 'supplier' && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'update_profile') {
    $my_id   = (int)$_SESSION['supplier_id'];
    $contact = trim($_POST['contact_person']);
    $email   = trim($_POST['email']);
    $phone   = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $st = $conn->prepare("UPDATE suppliers SET contact_person=?,email=?,phone=?,address=? WHERE id=?");
    $st->bind_param("ssssi", $contact, $email, $phone, $address, $my_id);
    $st->execute();
    $msg = 'success:Profile updated!';
}

// ───────────────────────────────────────────
//  FETCH DATA based on role
// ───────────────────────────────────────────

if ($role === 'admin') {

    // ADMIN → fetch ALL approved suppliers
    $search = trim($_GET['search'] ?? '');
    $where  = "WHERE s.status='approved'";
    if ($search) {
        $s = mysqli_real_escape_string($conn, $search);
        $where .= " AND (s.company_name LIKE '%$s%' OR s.contact_person LIKE '%$s%')";
    }
    $result = $conn->query("
        SELECT s.*,
               (SELECT COUNT(*) FROM products WHERE supplier_id = s.id) AS prod_count
        FROM suppliers s
        $where
        ORDER BY s.id ASC
    ");

} elseif ($role === 'supplier') {

    // SUPPLIER → fetch ONLY their own row using their session supplier_id
    $my_id  = (int)$_SESSION['supplier_id'];
    $result = $conn->query("
        SELECT s.*,
               (SELECT COUNT(*)              FROM products WHERE supplier_id = s.id) AS prod_count,
               (SELECT COUNT(*)              FROM orders   WHERE supplier_id = s.id) AS order_count,
               (SELECT COUNT(*)              FROM orders   WHERE supplier_id = s.id AND status = 'Pending')   AS pend_count,
               (SELECT COUNT(*)              FROM orders   WHERE supplier_id = s.id AND status = 'Delivered') AS deliv_count,
               (SELECT COUNT(*)              FROM orders   WHERE supplier_id = s.id AND status = 'Cancelled') AS cancl_count
        FROM suppliers s
        WHERE s.id = $my_id
    ");
    $my_row = $result->fetch_assoc();   // single row

    // Their products
    $my_products = $conn->query("
        SELECT p.*, c.name AS cat_name
        FROM   products p
        LEFT JOIN categories c ON c.id = p.category_id
        WHERE  p.supplier_id = $my_id
        ORDER  BY p.id ASC
    ");

    // Their orders (latest 10)
    $my_orders = $conn->query("
        SELECT o.*, p.name AS product_name
        FROM   orders o
        LEFT JOIN products p ON p.id = o.product_id
        WHERE  o.supplier_id = $my_id
        ORDER  BY o.created_at DESC
        LIMIT  10
    ");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>InvTrack — <?= $role === 'admin' ? 'All Suppliers' : 'My Profile' ?></title>
<link rel="stylesheet" href="css/style.css"/>
<style>
/* ─── Modal ─── */
.modal-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.72); z-index:300; align-items:center; justify-content:center; backdrop-filter:blur(5px); }
.modal-overlay.open { display:flex; }
.modal { background:var(--surface); border:1px solid var(--border); border-radius:18px; padding:30px; width:520px; max-width:95vw; max-height:90vh; overflow-y:auto; box-shadow:0 0 60px var(--glow); }
.modal-title { font-size:1.1rem; font-weight:800; font-style:italic; margin-bottom:20px; }
.fgrid2 { display:grid; grid-template-columns:1fr 1fr; gap:13px; }

/* ─── Supplier profile ─── */
.mini-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:20px; }
.ms { background:var(--card); border:1px solid var(--border); border-radius:12px; padding:14px; text-align:center; }
.ms-v { font-size:1.6rem; font-weight:900; font-style:italic; }
.ms-l { font-size:.68rem; text-transform:uppercase; letter-spacing:.08em; color:var(--muted); margin-top:4px; font-weight:700; }

.profile-box { background:var(--card); border:1px solid var(--border); border-radius:16px; padding:26px; margin-bottom:20px; }
.profile-top { display:flex; align-items:center; gap:16px; margin-bottom:20px; padding-bottom:18px; border-bottom:1px solid var(--border); }
.p-av { width:54px; height:54px; border-radius:50%; background:linear-gradient(135deg,var(--accent),var(--accent2)); display:flex; align-items:center; justify-content:center; font-size:1.4rem; font-weight:900; color:#fff; flex-shrink:0; box-shadow:0 0 20px var(--glow); }
.p-name { font-size:1.15rem; font-weight:800; font-style:italic; }
.p-sub  { font-size:.76rem; color:var(--muted); margin-top:4px; }
.pf-grid { display:grid; grid-template-columns:1fr 1fr; gap:14px; }
.pf { display:flex; flex-direction:column; gap:4px; }
.pf-l { font-size:.68rem; text-transform:uppercase; letter-spacing:.1em; color:var(--muted); font-weight:700; }
.pf-v { font-size:.88rem; }
</style>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div id="main">
  <div class="topbar">
    <h1><?= $role === 'admin' ? 'Suppliers' : 'My Supplier Profile' ?></h1>
    <div class="topbar-badges">
      <span class="chip chip-<?= $role ?>"><?= $role === 'admin' ? '👑 Admin' : '🏭 Supplier' ?></span>
      <span class="chip chip-live">🟢 Live</span>
    </div>
  </div>

  <div class="content">

    <?php if ($msg): [$t, $m] = explode(':', $msg, 2); ?>
      <div class="alert alert-<?= $t === 'success' ? 'success' : 'danger' ?>"><?= htmlspecialchars($m) ?></div>
    <?php endif; ?>

    <!-- ══════════════════════════════════════
         ADMIN VIEW — full table of all suppliers
    ══════════════════════════════════════ -->
    <?php if ($role === 'admin'): ?>

    <div class="card">
      <div class="card-header">
        <form method="GET" style="display:flex;gap:9px;align-items:center;flex-wrap:wrap">
          <div class="search-box">
            🔍
            <input type="text" name="search" placeholder="Search suppliers…"
                   value="<?= htmlspecialchars($search ?? '') ?>"/>
          </div>
          <?php if (!empty($search)): ?>
            <a href="suppliers.php" class="btn btn-outline btn-sm">✕ Clear</a>
          <?php endif; ?>
        </form>
        <button class="btn btn-primary" onclick="openAddModal()">+ Add Supplier</button>
      </div>

      <table>
        <thead>
          <tr>
            <th>Code</th><th>Company</th><th>Contact</th><th>Email</th>
            <th>Phone</th><th>Address</th><th>Products</th><th>Actions</th>
          </tr>
        </thead>
        <tbody>
        <?php while ($s = $result->fetch_assoc()): ?>
          <tr>
            <td style="color:var(--muted);font-size:.76rem"><?= htmlspecialchars($s['supplier_code']) ?></td>
            <td><strong><?= htmlspecialchars($s['company_name']) ?></strong></td>
            <td><?= htmlspecialchars($s['contact_person'] ?? '—') ?></td>
            <td><a href="mailto:<?= $s['email'] ?>" style="color:var(--accent3)"><?= htmlspecialchars($s['email'] ?? '—') ?></a></td>
            <td><?= htmlspecialchars($s['phone'] ?? '—') ?></td>
            <td style="color:var(--muted);font-size:.8rem"><?= htmlspecialchars(substr($s['address'] ?? '—', 0, 30)) ?></td>
            <td><span class="tag tag-ok"><?= $s['prod_count'] ?> Products</span></td>
            <td>
              <button class="btn btn-outline btn-sm"
                      onclick='openEditModal(<?= json_encode($s) ?>)'>✏</button>
              <form method="POST" style="display:inline"
                    onsubmit="return confirm('Delete this supplier?')">
                <input type="hidden" name="action" value="delete"/>
                <input type="hidden" name="supplier_id" value="<?= $s['id'] ?>"/>
                <button type="submit" class="btn btn-danger btn-sm">🗑</button>
              </form>
            </td>
          </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div><!-- /card -->

    <!-- ══════════════════════════════════════
         SUPPLIER VIEW — only their own details
    ══════════════════════════════════════ -->
    <?php elseif ($role === 'supplier' && $my_row): ?>

    <!-- Mini stats -->
    <div class="mini-stats">
      <div class="ms">
        <div class="ms-v" style="color:var(--accent2)"><?= $my_row['prod_count'] ?></div>
        <div class="ms-l">My Products</div>
      </div>
      <div class="ms">
        <div class="ms-v"><?= $my_row['order_count'] ?></div>
        <div class="ms-l">Total Orders</div>
      </div>
      <div class="ms">
        <div class="ms-v" style="color:#fcd34d"><?= $my_row['pend_count'] ?></div>
        <div class="ms-l">Pending</div>
      </div>
      <div class="ms">
        <div class="ms-v" style="color:#34d399"><?= $my_row['deliv_count'] ?></div>
        <div class="ms-l">Delivered</div>
      </div>
    </div>

    <!-- Profile card -->
    <div class="profile-box">
      <div class="profile-top">
        <div class="p-av"><?= strtoupper($my_row['company_name'][0]) ?></div>
        <div>
          <div class="p-name"><?= htmlspecialchars($my_row['company_name']) ?></div>
          <div class="p-sub">
            <?= htmlspecialchars($my_row['supplier_code']) ?>
            &nbsp;·&nbsp;
            <span class="tag tag-approved">✅ Approved</span>
          </div>
        </div>
        <button class="btn btn-primary btn-sm"
                onclick="openProfileModal()" style="margin-left:auto">✏ Edit Profile</button>
      </div>

      <div class="pf-grid">
        <div class="pf">
          <div class="pf-l">Contact Person</div>
          <div class="pf-v"><?= htmlspecialchars($my_row['contact_person'] ?? '—') ?></div>
        </div>
        <div class="pf">
          <div class="pf-l">Email</div>
          <div class="pf-v">
            <a href="mailto:<?= $my_row['email'] ?>" style="color:var(--accent3)">
              <?= htmlspecialchars($my_row['email'] ?? '—') ?>
            </a>
          </div>
        </div>
        <div class="pf">
          <div class="pf-l">Phone</div>
          <div class="pf-v"><?= htmlspecialchars($my_row['phone'] ?? '—') ?></div>
        </div>
        <div class="pf">
          <div class="pf-l">Username</div>
          <div class="pf-v" style="color:var(--accent3)"><?= htmlspecialchars($my_row['username'] ?? '—') ?></div>
        </div>
        <div class="pf" style="grid-column:span 2">
          <div class="pf-l">Address</div>
          <div class="pf-v"><?= htmlspecialchars($my_row['address'] ?? '—') ?></div>
        </div>
        <div class="pf">
          <div class="pf-l">Joined</div>
          <div class="pf-v" style="color:var(--muted)"><?= date('d M Y', strtotime($my_row['created_at'])) ?></div>
        </div>
        <div class="pf">
          <div class="pf-l">Cancelled Orders</div>
          <div class="pf-v" style="color:#f87171"><?= $my_row['cancl_count'] ?></div>
        </div>
      </div>
    </div><!-- /profile-box -->

    <!-- My Products -->
    <div class="card" style="margin-bottom:20px">
      <div class="card-header">
        <span class="card-title">📦 My Products (<?= $my_row['prod_count'] ?>)</span>
      </div>
      <table>
        <thead>
          <tr><th>Code</th><th>Name</th><th>Category</th><th>Stock</th><th>Unit Price</th><th>Status</th></tr>
        </thead>
        <tbody>
        <?php if ($my_row['prod_count'] == 0): ?>
          <tr><td colspan="6" style="text-align:center;color:var(--muted);padding:26px">
            No products assigned to your account yet.
          </td></tr>
        <?php else: ?>
          <?php while ($p = $my_products->fetch_assoc()):
                $low = $p['stock'] <= $p['min_threshold']; ?>
          <tr>
            <td style="color:var(--muted);font-size:.76rem"><?= $p['product_code'] ?></td>
            <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
            <td><?= htmlspecialchars($p['cat_name'] ?? '—') ?></td>
            <td>
              <?= $p['stock'] ?>
              <?php if ($low): ?><span style="color:#f87171;font-size:.7rem"> ⚠ Low</span><?php endif; ?>
            </td>
            <td>₹<?= number_format($p['price'], 2) ?></td>
            <td><span class="tag tag-<?= $low ? 'low' : 'ok' ?>"><?= $low ? 'Low Stock' : 'In Stock' ?></span></td>
          </tr>
          <?php endwhile; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>

    <!-- My Orders -->
    <div class="card">
      <div class="card-header">
        <span class="card-title">🛒 My Recent Orders</span>
        <a href="orders.php" class="btn btn-outline btn-sm">View All →</a>
      </div>
      <table>
        <thead>
          <tr><th>Order ID</th><th>Product</th><th>Qty</th><th>Unit Price</th><th>Total</th><th>Status</th><th>Date</th></tr>
        </thead>
        <tbody>
        <?php if ($my_row['order_count'] == 0): ?>
          <tr><td colspan="7" style="text-align:center;color:var(--muted);padding:26px">
            No orders found for your account.
          </td></tr>
        <?php else: ?>
          <?php while ($o = $my_orders->fetch_assoc()):
                $sc = strtolower($o['status']); ?>
          <tr>
            <td style="color:var(--accent3)"><?= $o['order_code'] ?></td>
            <td><?= htmlspecialchars($o['product_name']) ?></td>
            <td><?= $o['quantity'] ?></td>
            <td>₹<?= number_format($o['unit_price'], 2) ?></td>
            <td><strong>₹<?= number_format($o['quantity'] * $o['unit_price'], 2) ?></strong></td>
            <td><span class="tag tag-<?= $sc ?>"><?= $o['status'] ?></span></td>
            <td style="color:var(--muted)"><?= $o['order_date'] ?></td>
          </tr>
          <?php endwhile; ?>
        <?php endif; ?>
        </tbody>
      </table>
    </div>

    <?php endif; ?>

  </div><!-- /content -->
</div><!-- /main -->


<!-- ══════════════════════════════════════
     ADMIN MODALS: Add / Edit supplier
══════════════════════════════════════ -->
<?php if ($role === 'admin'): ?>

<div class="modal-overlay" id="sup-modal">
  <div class="modal">
    <div class="modal-title" id="modal-title">Add Supplier</div>
    <form method="POST">
      <input type="hidden" name="action"      id="f-action" value="add"/>
      <input type="hidden" name="supplier_id" id="f-id"     value=""/>
      <div class="fgrid2">
        <div class="fg full"><label>Company Name *</label>
          <input type="text" name="company_name" id="f-name" required/></div>
        <div class="fg"><label>Contact Person</label>
          <input type="text" name="contact_person" id="f-contact"/></div>
        <div class="fg"><label>Email</label>
          <input type="email" name="email" id="f-email"/></div>
        <div class="fg"><label>Phone</label>
          <input type="text" name="phone" id="f-phone"/></div>
        <div class="fg full"><label>Address</label>
          <textarea name="address" id="f-address"></textarea></div>
      </div>
      <div class="form-actions">
        <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
    </form>
  </div>
</div>

<script>
function openAddModal() {
  document.getElementById('modal-title').textContent = 'Add Supplier';
  document.getElementById('f-action').value = 'add';
  ['f-id','f-name','f-contact','f-email','f-phone','f-address']
    .forEach(id => document.getElementById(id).value = '');
  document.getElementById('sup-modal').classList.add('open');
}
function openEditModal(s) {
  document.getElementById('modal-title').textContent = 'Edit Supplier';
  document.getElementById('f-action').value  = 'edit';
  document.getElementById('f-id').value      = s.id;
  document.getElementById('f-name').value    = s.company_name;
  document.getElementById('f-contact').value = s.contact_person || '';
  document.getElementById('f-email').value   = s.email   || '';
  document.getElementById('f-phone').value   = s.phone   || '';
  document.getElementById('f-address').value = s.address || '';
  document.getElementById('sup-modal').classList.add('open');
}
function closeModal() {
  document.getElementById('sup-modal').classList.remove('open');
}
document.getElementById('sup-modal')
  .addEventListener('click', e => { if (e.target.id === 'sup-modal') closeModal(); });
</script>

<?php endif; ?>


<!-- ══════════════════════════════════════
     SUPPLIER MODAL: Edit own profile
══════════════════════════════════════ -->
<?php if ($role === 'supplier' && $my_row): ?>

<div class="modal-overlay" id="profile-modal">
  <div class="modal">
    <div class="modal-title">Edit My Profile</div>
    <form method="POST">
      <input type="hidden" name="action" value="update_profile"/>
      <div class="fgrid2">
        <div class="fg"><label>Contact Person</label>
          <input type="text" name="contact_person"
                 value="<?= htmlspecialchars($my_row['contact_person'] ?? '') ?>"/></div>
        <div class="fg"><label>Email</label>
          <input type="email" name="email"
                 value="<?= htmlspecialchars($my_row['email'] ?? '') ?>"/></div>
        <div class="fg"><label>Phone</label>
          <input type="text" name="phone"
                 value="<?= htmlspecialchars($my_row['phone'] ?? '') ?>"/></div>
        <div class="fg full"><label>Address</label>
          <textarea name="address"><?= htmlspecialchars($my_row['address'] ?? '') ?></textarea></div>
      </div>
      <div class="form-actions">
        <button type="button" class="btn btn-outline" onclick="closeProfileModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </div>
    </form>
  </div>
</div>

<script>
function openProfileModal()  { document.getElementById('profile-modal').classList.add('open'); }
function closeProfileModal() { document.getElementById('profile-modal').classList.remove('open'); }
document.getElementById('profile-modal')
  .addEventListener('click', e => { if (e.target.id === 'profile-modal') closeProfileModal(); });
</script>

<?php endif; ?>
</body>
</html>