<?php
require_once 'includes/db.php';
if (isset($_SESSION['user_id'])) { header('Location: dashboard.php'); exit; }

$error = ''; $success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $company  = trim($_POST['company_name']);
    $contact  = trim($_POST['contact_person']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $address  = trim($_POST['address']);
    $username = trim($_POST['username']);
    $password = md5(trim($_POST['password']));

    if (!$company || !$contact || !$email || !$username || !$_POST['password']) {
        $error = 'Please fill in all required fields.';
    } else {
        $chk = $conn->prepare("SELECT id FROM suppliers WHERE username=?");
        $chk->bind_param("s", $username);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $error = 'Username already taken. Please choose another.';
        } else {
            $res = $conn->query("SELECT COUNT(*) as c FROM suppliers");
            $cnt = $res->fetch_assoc()['c'] + 1;
            $code = 'S' . str_pad($cnt, 3, '0', STR_PAD_LEFT);
            $stmt = $conn->prepare("INSERT INTO suppliers (supplier_code,company_name,contact_person,email,phone,address,username,password,status) VALUES (?,?,?,?,?,?,?,?,'pending')");
            $stmt->bind_param("ssssssss", $code, $company, $contact, $email, $phone, $address, $username, $password);
            if ($stmt->execute()) {
                $success = true;
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>InvTrack — Supplier Registration</title>
<style>
/* ── BRIGHT THEME REGISTER PAGE ── */
*{margin:0;padding:0;box-sizing:border-box;}
body{
  background:#f0f4ff;
  color:#1e1b4b;
  font-family:'Times New Roman',Times,serif;
  min-height:100vh;
  display:flex; align-items:center; justify-content:center;
  padding:30px 16px;
}
body::before{
  content:''; position:fixed; inset:0;
  background-image:
    linear-gradient(rgba(79,70,229,.05) 1px,transparent 1px),
    linear-gradient(90deg,rgba(79,70,229,.05) 1px,transparent 1px);
  background-size:40px 40px; pointer-events:none;
}

/* ── Outer wrapper: two columns ── */
.reg-wrap{
  display:flex; width:900px; max-width:98vw;
  border-radius:22px; overflow:hidden;
  border:1.5px solid #c7d2fe;
  box-shadow:0 12px 50px rgba(79,70,229,.2);
  position:relative; z-index:1;
}

/* ── LEFT INFO PANEL (blue) ── */
.reg-left{
  width:300px; flex-shrink:0;
  background:#4f46e5;
  padding:44px 32px;
  display:flex; flex-direction:column; justify-content:center;
}
.reg-logo{
  font-size:1.8rem; font-weight:900; color:#ffffff;
  letter-spacing:-1px; font-style:italic; margin-bottom:6px;
}
.reg-logo span{color:#c7d2fe;}
.reg-tagline{ font-size:.82rem; color:rgba(255,255,255,.72); margin-bottom:32px; line-height:1.6; }
.info-title{ font-size:.7rem; text-transform:uppercase; letter-spacing:.12em; color:#c7d2fe; font-weight:700; margin-bottom:14px; }
.info-item{
  display:flex; align-items:flex-start; gap:10px;
  margin-bottom:14px; font-size:.8rem;
  color:rgba(255,255,255,.8); line-height:1.55;
}
.info-dot{
  width:22px; height:22px; border-radius:50%;
  background:rgba(255,255,255,.2);
  display:flex; align-items:center; justify-content:center;
  font-size:.75rem; font-weight:700; color:#fff;
  flex-shrink:0; margin-top:1px;
}
.back-link{
  display:inline-flex; align-items:center; gap:6px;
  margin-top:32px; font-size:.8rem; color:#c7d2fe;
  text-decoration:none; font-weight:700;
  padding:8px 14px;
  background:rgba(255,255,255,.14);
  border:1px solid rgba(255,255,255,.28);
  border-radius:8px; transition:all .2s; width:fit-content;
}
.back-link:hover{ background:rgba(255,255,255,.24); }

/* ── RIGHT FORM PANEL (white) ── */
.reg-right{
  flex:1;
  background:#ffffff;
  padding:40px 36px;
  overflow-y:auto;
}
.reg-title{
  font-size:1.35rem; font-weight:800;
  font-style:italic; color:#1e1b4b;
  margin-bottom:6px;
}
.reg-sub{ font-size:.82rem; color:#6b7280; margin-bottom:24px; }

/* Alert boxes */
.alert-danger{
  background:#fee2e2; border:1px solid #fca5a5;
  color:#991b1b; border-radius:9px;
  padding:12px 14px; font-size:.83rem; margin-bottom:18px;
}
.alert-success{
  background:#dcfce7; border:1px solid #86efac;
  color:#166534; border-radius:12px;
  padding:22px; font-size:.9rem; margin-bottom:14px;
  text-align:center; line-height:1.8;
}
.alert-success strong{ display:block; font-size:1rem; margin-bottom:4px; }

/* Notice box */
.notice-box{
  background:#fef3c7; border:1px solid #fcd34d;
  color:#92400e; border-radius:9px;
  padding:11px 14px; font-size:.8rem;
  margin-bottom:20px; line-height:1.6;
}

/* Form grid */
.form-grid{ display:grid; grid-template-columns:1fr 1fr; gap:14px; }

/* Form group */
.fg{ display:flex; flex-direction:column; gap:6px; }
.fg.full{ grid-column:span 2; }
.fg label{
  font-size:.7rem; text-transform:uppercase;
  letter-spacing:.1em; color:#4f46e5; font-weight:700;
}
.fg input, .fg textarea{
  background:#f5f3ff; border:1.5px solid #c7d2fe;
  color:#1e1b4b; padding:11px 13px;
  border-radius:9px; font-family:'Times New Roman',serif;
  font-size:.88rem; outline:none; width:100%;
  transition:border-color .2s, box-shadow .2s;
}
.fg input:focus, .fg textarea:focus{
  border-color:#4f46e5;
  box-shadow:0 0 0 3px rgba(79,70,229,.12);
  background:#ffffff;
}
.fg textarea{ resize:vertical; min-height:72px; }

/* Required star */
.req{ color:#dc2626; margin-left:2px; }

/* Submit button */
.btn-submit{
  width:100%; padding:13px;
  background:#4f46e5;
  border:none; border-radius:10px;
  color:#ffffff; font-family:'Times New Roman',serif;
  font-size:1rem; font-weight:700;
  cursor:pointer; transition:all .2s;
  box-shadow:0 4px 14px rgba(79,70,229,.3);
  letter-spacing:.5px; margin-top:20px;
}
.btn-submit:hover{
  background:#4338ca;
  transform:translateY(-2px);
  box-shadow:0 8px 24px rgba(79,70,229,.4);
}

/* Login link */
.login-link{
  text-align:center; font-size:.82rem;
  color:#6b7280; margin-top:16px;
}
.login-link a{
  color:#4f46e5; text-decoration:none; font-weight:700;
}
.login-link a:hover{ text-decoration:underline; }

/* Success go-back btn */
.btn-go{
  display:inline-block;
  margin-top:16px;
  padding:11px 24px;
  background:#4f46e5;
  color:#fff; border-radius:9px;
  font-family:'Times New Roman',serif;
  font-size:.9rem; font-weight:700;
  text-decoration:none; transition:all .2s;
}
.btn-go:hover{ background:#4338ca; }
</style>
</head>
<body>

<div class="reg-wrap">

  <!-- LEFT: Info panel -->
  <div class="reg-left">
    <div class="reg-logo">Inv<span>Track</span></div>
    <div class="reg-tagline">Inventory Management System</div>

    <div class="info-title">Registration steps</div>

    <div class="info-item">
      <div class="info-dot">1</div>
      Fill in your company and contact details below.
    </div>
    <div class="info-item">
      <div class="info-dot">2</div>
      Choose a username and password for your account.
    </div>
    <div class="info-item">
      <div class="info-dot">3</div>
      Submit — Admin will review and approve your account.
    </div>
    <div class="info-item">
      <div class="info-dot">4</div>
      Once approved, login with your credentials.
    </div>

    <a href="index.php?tab=supplier" class="back-link">← Back to Login</a>
  </div>

  <!-- RIGHT: Form -->
  <div class="reg-right">

    <?php if($success): ?>
    <!-- SUCCESS STATE -->
    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:400px;text-align:center">
      <div style="font-size:3.5rem;margin-bottom:16px">✅</div>
      <div class="alert-success" style="max-width:380px">
        <strong>Registration Submitted!</strong>
        Your supplier account has been submitted for review.<br>
        Please wait for <strong style="color:#166534">Admin Approval</strong> before trying to login.<br>
        You will be able to login once the admin approves your account.
      </div>
      <a href="index.php?tab=supplier" class="btn-go">← Go to Login</a>
    </div>

    <?php else: ?>
    <!-- FORM STATE -->
    <div class="reg-title">Supplier Registration</div>
    <div class="reg-sub">Create your supplier account — admin approval required before login.</div>

    <?php if($error): ?>
    <div class="alert-danger">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="notice-box">
      ⚠ After submitting, your account will be in <strong>Pending</strong> status. The admin must approve it before you can login.
    </div>

    <form method="POST" action="register.php">
      <div class="form-grid">

        <div class="fg full">
          <label>Company / Supplier Name <span class="req">*</span></label>
          <input type="text" name="company_name"
                 placeholder="e.g. TechCorp Pvt Ltd"
                 value="<?= htmlspecialchars($_POST['company_name'] ?? '') ?>"
                 required/>
        </div>

        <div class="fg">
          <label>Contact Person <span class="req">*</span></label>
          <input type="text" name="contact_person"
                 placeholder="Your full name"
                 value="<?= htmlspecialchars($_POST['contact_person'] ?? '') ?>"
                 required/>
        </div>

        <div class="fg">
          <label>Email <span class="req">*</span></label>
          <input type="email" name="email"
                 placeholder="company@email.com"
                 value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                 required/>
        </div>

        <div class="fg">
          <label>Phone</label>
          <input type="text" name="phone"
                 placeholder="+91 9876543210"
                 value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"/>
        </div>

        <div class="fg">
          <label>Username <span class="req">*</span></label>
          <input type="text" name="username"
                 placeholder="Choose a unique username"
                 value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                 required/>
        </div>

        <div class="fg">
          <label>Password <span class="req">*</span></label>
          <input type="password" name="password"
                 placeholder="Create a strong password"
                 required/>
        </div>

        <div class="fg full">
          <label>Address</label>
          <textarea name="address"
                    placeholder="Company address (optional)"><?= htmlspecialchars($_POST['address'] ?? '') ?></textarea>
        </div>

      </div>

      <button type="submit" class="btn-submit">Submit for Approval →</button>
    </form>

    <div class="login-link">
      Already have an account? <a href="index.php?tab=supplier">Login here</a>
    </div>

    <?php endif; ?>

  </div><!-- /reg-right -->
</div><!-- /reg-wrap -->

</body>
</html>