-- ============================================================
--  InvTrack — Inventory Management System
--  DBMS Project | MySQL Database Schema
--  Import this file in phpMyAdmin
-- ============================================================

CREATE DATABASE IF NOT EXISTS invtrack;
USE invtrack;

-- ─── ADMIN TABLE ───
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL DEFAULT 'Super Admin',
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Default admin: username=admin, password=admin123
INSERT INTO admin (name, username, password)
VALUES ('Super Admin', 'admin', MD5('admin123'));

-- ─── SUPPLIERS TABLE ───
CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    supplier_code VARCHAR(10) UNIQUE,
    company_name VARCHAR(150) NOT NULL,
    contact_person VARCHAR(100),
    email VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    username VARCHAR(50) UNIQUE,
    password VARCHAR(255),
    status ENUM('pending','approved','rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Demo approved suppliers
INSERT INTO suppliers (supplier_code, company_name, contact_person, email, phone, address, username, password, status)
VALUES
('S001','TechCorp Pvt Ltd','Arjun Sharma','arjun@techcorp.in','+91 9876543210','Bengaluru, Karnataka','techsup',MD5('pass123'),'approved'),
('S002','GlobalGoods India','Priya Nair','priya@globalgoods.in','+91 8765432109','Mumbai, Maharashtra','globalsup',MD5('pass123'),'approved'),
('S003','QuickSupply Co.','Rajan Kumar','rajan@quicksupply.in','+91 7654321098','Chennai, Tamil Nadu','quicksup',MD5('pass123'),'approved');

-- ─── CATEGORIES TABLE ───
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO categories (name) VALUES ('Electronics'),('Furniture'),('Stationery'),('Networking'),('Accessories');

-- ─── PRODUCTS TABLE ───
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_code VARCHAR(10) UNIQUE,
    name VARCHAR(150) NOT NULL,
    category_id INT,
    stock INT DEFAULT 0,
    price DECIMAL(10,2) DEFAULT 0.00,
    min_threshold INT DEFAULT 10,
    supplier_id INT,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
);

INSERT INTO products (product_code, name, category_id, stock, price, min_threshold, supplier_id, description)
VALUES
('P001','Wireless Mouse',1,42,850.00,10,1,'Ergonomic 2.4GHz wireless mouse'),
('P002','USB-C Hub',1,7,1200.00,15,1,'7-in-1 USB hub with HDMI'),
('P003','Office Chair',2,5,8500.00,8,2,'Ergonomic mesh office chair'),
('P004','A4 Paper Ream',3,120,280.00,30,3,'500 sheets per ream, 80gsm'),
('P005','Laptop Stand',1,28,1500.00,10,1,'Adjustable aluminum laptop stand'),
('P006','Whiteboard Marker',3,3,50.00,20,3,'Blue, black, red set of 3'),
('P007','Standing Desk',2,12,22000.00,5,2,'Electric height-adjustable desk'),
('P008','Mechanical Keyboard',1,19,3500.00,10,1,'TKL layout, Cherry MX Blues');

-- ─── ORDERS TABLE ───
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_code VARCHAR(15) UNIQUE,
    product_id INT,
    quantity INT NOT NULL,
    unit_price DECIMAL(10,2),
    supplier_id INT,
    status ENUM('Pending','Delivered','Cancelled') DEFAULT 'Pending',
    order_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL
);

INSERT INTO orders (order_code, product_id, quantity, unit_price, supplier_id, status, order_date)
VALUES
('ORD001',1,20,850.00,1,'Delivered','2024-06-01'),
('ORD002',3,3,8500.00,2,'Pending','2024-06-10'),
('ORD003',4,50,280.00,3,'Delivered','2024-06-12'),
('ORD004',6,30,50.00,3,'Pending','2024-06-15'),
('ORD005',2,10,1200.00,1,'Cancelled','2024-06-18');