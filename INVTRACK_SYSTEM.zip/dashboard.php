<?php
require_once 'includes/db.php';
requireLogin();
$role = $_SESSION['role'];
$name = $_SESSION['name'];

// ═══════════════════════════════════════════════════════
//  ADMIN DASHBOARD — sees ALL data across the system
// ═══════════════════════════════════════════════════════
if ($role === 'admin') {

    $totalProducts  = $conn->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
    $totalValue     = $conn->query("SELECT SUM(stock * price) as v FROM products")->fetch_assoc()['v'] ?? 0;
    $totalSuppliers = $conn->query("SELECT COUNT(*) as c FROM suppliers WHERE status='approved'")->fetch_assoc()['c'];
    $lowStockCount  = $conn->query("SELECT COUNT(*) as c FROM products WHERE stock <= min_threshold")->fetch_assoc()['c'];
    $pendingApprovals = $conn->query("SELECT COUNT(*) as c FROM suppliers WHERE status='pending'")->fetch_assoc()['c'];

    // Stock by category (all products)
    $catRows = $conn->query("SELECT c.name, SUM(p.stock) as total FROM products p LEFT JOIN categories c ON p.category_id=c.id GROUP BY c.id ORDER BY total DESC");
    $cats = []; while($r=$catRows->fetch_assoc()) $cats[] = $r;
    $maxCat = max(array_column($cats,'total') ?: [1]);

    // Order status distribution (all orders)
    $ordStatus  = $conn->query("SELECT status, COUNT(*) as c FROM orders GROUP BY status");
    $statusData = ['Pending'=>0,'Delivered'=>0,'Cancelled'=>0];
    while($r=$ordStatus->fetch_assoc()) $statusData[$r['status']] = $r['c'];

    // Recent 5 orders (all suppliers)
    $recentOrders = $conn->query("
        SELECT o.order_code, p.name as product_name, o.quantity, s.company_name, o.status, o.order_date
        FROM orders o
        LEFT JOIN products p ON o.product_id = p.id
        LEFT JOIN suppliers s ON o.supplier_id = s.id
        ORDER BY o.created_at DESC LIMIT 5
    ");

// ═══════════════════════════════════════════════════════
//  SUPPLIER DASHBOARD — sees ONLY their own data
// ═══════════════════════════════════════════════════════
} elseif ($role === 'supplier') {

    $sid = (int)$_SESSION['supplier_id'];

    // Stats: only THIS supplier's data
    $myProducts    = $conn->query("SELECT COUNT(*) as c FROM products WHERE supplier_id=$sid")->fetch_assoc()['c'];
    $myStockValue  = $conn->query("SELECT SUM(stock*price) as v FROM products WHERE supplier_id=$sid")->fetch_assoc()['v'] ?? 0;
    $myOrders      = $conn->query("SELECT COUNT(*) as c FROM orders WHERE supplier_id=$sid")->fetch_assoc()['c'];
    $myPending     = $conn->query("SELECT COUNT(*) as c FROM orders WHERE supplier_id=$sid AND status='Pending'")->fetch_assoc()['c'];
    $myDelivered   = $conn->query("SELECT COUNT(*) as c FROM orders WHERE supplier_id=$sid AND status='Delivered'")->fetch_assoc()['c'];
    $myCancelled   = $conn->query("SELECT COUNT(*) as c FROM orders WHERE supplier_id=$sid AND status='Cancelled'")->fetch_assoc()['c'];
    $myLowStock    = $conn->query("SELECT COUNT(*) as c FROM products WHERE supplier_id=$sid AND stock<=min_threshold")->fetch_assoc()['c'];

    // My products by category (only this supplier's products)
    $catRows = $conn->query("SELECT c.name, SUM(p.stock) as total FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.supplier_id=$sid GROUP BY c.id ORDER BY total DESC");
    $cats = []; while($r=$catRows->fetch_assoc()) $cats[] = $r;
    $maxCat = max(array_column($cats,'total') ?: [1]);

    // Order status (only this supplier's orders)
    $statusData = ['Pending'=>$myPending,'Delivered'=>$myDelivered,'Cancelled'=>$myCancelled];

    // Recent 5 orders (only this supplier's orders)
    $recentOrders = $conn->query("
        SELECT o.order_code, p.name as product_name, o.quantity, s.company_name, o.status, o.order_date
        FROM orders o
        LEFT JOIN products p ON o.product_id = p.id
        LEFT JOIN suppliers s ON o.supplier_id = s.id
        WHERE o.supplier_id = $sid
        ORDER BY o.created_at DESC LIMIT 5
    ");

    // My products list (for supplier only)
    $myProductsList = $conn->query("
        SELECT p.product_code, p.name, c.name as cat, p.stock, p.price, p.min_threshold
        FROM products p LEFT JOIN categories c ON p.category_id=c.id
        WHERE p.supplier_id=$sid ORDER BY p.id
    ");

    // Supplier info
    $supplierInfo = $conn->query("SELECT * FROM suppliers WHERE id=$sid")->fetch_assoc();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>InvTrack — Dashboard</title>
<link rel="stylesheet" href="css/style.css"/>
<style>
/* Supplier profile banner */
.sup-banner{
  background:#ffffff; border:1.5px solid #c7d2fe;
  border-radius:14px; padding:22px 24px;
  display:flex; align-items:center; gap:18px;
  margin-bottom:20px;
  box-shadow:0 2px 10px rgba(79,70,229,.07);
}
.sup-banner-av{
  width:54px; height:54px; border-radius:50%;
  background:linear-gradient(135deg,#4f46e5,#6366f1);
  display:flex; align-items:center; justify-content:center;
  font-size:1.4rem; font-weight:900; color:#fff; flex-shrink:0;
  box-shadow:0 4px 14px rgba(79,70,229,.3);
}
.sup-banner-info{ flex:1; }
.sup-banner-name{ font-size:1.1rem; font-weight:800; font-style:italic; color:#4f46e5; }
.sup-banner-meta{ font-size:.78rem; color:#6b7280; margin-top:3px; }
.sup-banner-status{ }

/* Donut centre white for bright theme */
.donut-center-fill{ fill:#ffffff; }
</style>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div id="main">
  <div class="topbar">
    <h1><?= $role==='admin' ? 'Dashboard' : 'My Dashboard' ?></h1>
    <div class="topbar-badges">
      <?php if($role==='admin'): ?>
        <span class="chip chip-admin">👑 Admin</span>
        <?php if(($lowStockCount??0) > 0): ?>
          <span class="chip chip-low">⚠ <?= $lowStockCount ?> Low Stock</span>
        <?php endif; ?>
        <?php if(($pendingApprovals??0) > 0): ?>
          <span class="chip" style="background:#fef3c7;color:#92400e;border:1px solid #fcd34d">⏳ <?= $pendingApprovals ?> Pending</span>
        <?php endif; ?>
      <?php else: ?>
        <span class="chip chip-supplier">🏭 Supplier</span>
        <?php if(($myLowStock??0) > 0): ?>
          <span class="chip chip-low">⚠ <?= $myLowStock ?> Low Stock</span>
        <?php endif; ?>
      <?php endif; ?>
      <span class="chip chip-live">🟢 Live</span>
    </div>
  </div>

  <div class="content">

  <?php if($role === 'admin'): ?>
  <!-- ══════════════════════════════════════════
       ADMIN VIEW — full system overview
       ══════════════════════════════════════════ -->

    <!-- Admin stat cards -->
    <div class="stats-grid">
      <div class="stat-card sc-purple">
        <div class="stat-label">Total Products</div>
        <div class="stat-value"><?= $totalProducts ?></div>
        <div class="stat-sub">across all categories</div>
      </div>
      <div class="stat-card sc-gold">
        <div class="stat-label">Total Stock Value</div>
        <div class="stat-value">₹<?= number_format($totalValue,0,'.',',') ?></div>
        <div class="stat-sub">current inventory worth</div>
      </div>
      <div class="stat-card sc-green">
        <div class="stat-label">Active Suppliers</div>
        <div class="stat-value"><?= $totalSuppliers ?></div>
        <div class="stat-sub">approved vendors</div>
      </div>
      <div class="stat-card sc-red">
        <div class="stat-label">Low Stock Items</div>
        <div class="stat-value"><?= $lowStockCount ?></div>
        <div class="stat-sub">need reorder soon</div>
      </div>
    </div>

    <!-- Low stock alert -->
    <?php if($lowStockCount > 0): ?>
    <div class="alert alert-warn" style="margin-bottom:20px">
      ⚠️ <strong>Low stock alert!</strong> <?= $lowStockCount ?> product(s) are below minimum threshold.
      <a href="products.php" style="color:#92400e;font-weight:700">Check Products →</a>
    </div>
    <?php endif; ?>

    <!-- Charts -->
    <div class="charts-grid">
      <div class="chart-box">
        <div class="chart-title">Stock by Category</div>
        <div class="bar-chart">
          <?php foreach($cats as $cat): $h = ($cat['total']/$maxCat)*100; ?>
          <div class="bar-wrap">
            <div class="bar-val"><?= $cat['total'] ?></div>
            <div class="bar" style="height:<?= $h ?>px"></div>
            <div class="bar-label"><?= substr($cat['name'],0,6) ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="chart-box">
        <div class="chart-title">Order Status Distribution</div>
        <div style="display:flex;align-items:center;justify-content:center;gap:20px">
          <canvas id="donut" width="140" height="140"></canvas>
          <div>
            <?php $colors=['Pending'=>'#a855f7','Delivered'=>'#10b981','Cancelled'=>'#ef4444'];
                  foreach($statusData as $s=>$v): ?>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:.82rem">
              <div style="width:10px;height:10px;border-radius:50%;background:<?= $colors[$s] ?>"></div>
              <?= $s ?>: <strong><?= $v ?></strong>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>

    <!-- Recent Orders (all suppliers) -->
    <div class="card">
      <div class="card-header">
        <span class="card-title">Recent Orders — All Suppliers</span>
        <a href="orders.php" class="btn btn-outline btn-sm">View All →</a>
      </div>
      <table>
        <thead><tr><th>Order ID</th><th>Product</th><th>Qty</th><th>Supplier</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
        <?php while($row=$recentOrders->fetch_assoc()): $sc=strtolower($row['status']); ?>
        <tr>
          <td style="color:#4f46e5"><?= $row['order_code'] ?></td>
          <td><?= htmlspecialchars($row['product_name']) ?></td>
          <td><?= $row['quantity'] ?></td>
          <td><?= htmlspecialchars($row['company_name']) ?></td>
          <td><span class="tag tag-<?= $sc ?>"><?= $row['status'] ?></span></td>
          <td style="color:#6b7280"><?= $row['order_date'] ?></td>
        </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>

  <?php elseif($role === 'supplier'): ?>
  <!-- ══════════════════════════════════════════
       SUPPLIER VIEW — only their own company data
       ══════════════════════════════════════════ -->

    <!-- Company profile banner -->
    <div class="sup-banner">
      <div class="sup-banner-av"><?= strtoupper($supplierInfo['company_name'][0]) ?></div>
      <div class="sup-banner-info">
        <div class="sup-banner-name"><?= htmlspecialchars($supplierInfo['company_name']) ?></div>
        <div class="sup-banner-meta">
          <?= htmlspecialchars($supplierInfo['supplier_code']) ?> &nbsp;·&nbsp;
          <?= htmlspecialchars($supplierInfo['contact_person'] ?? '') ?> &nbsp;·&nbsp;
          <?= htmlspecialchars($supplierInfo['email'] ?? '') ?>
        </div>
      </div>
      <span class="tag tag-approved" style="font-size:.78rem;padding:5px 14px">✅ Approved</span>
    </div>

    <!-- Supplier stat cards — ONLY their own numbers -->
    <div class="stats-grid">
      <div class="stat-card sc-purple">
        <div class="stat-label">My Products</div>
        <div class="stat-value"><?= $myProducts ?></div>
        <div class="stat-sub">assigned to my account</div>
      </div>
      <div class="stat-card sc-gold">
        <div class="stat-label">My Stock Value</div>
        <div class="stat-value">₹<?= number_format($myStockValue,0,'.',',') ?></div>
        <div class="stat-sub">worth of my products</div>
      </div>
      <div class="stat-card sc-green">
        <div class="stat-label">My Total Orders</div>
        <div class="stat-value"><?= $myOrders ?></div>
        <div class="stat-sub">orders placed with me</div>
      </div>
      <div class="stat-card sc-red">
        <div class="stat-label">My Low Stock</div>
        <div class="stat-value"><?= $myLowStock ?></div>
        <div class="stat-sub">my products need reorder</div>
      </div>
    </div>

    <!-- Low stock alert for supplier's own products -->
    <?php if($myLowStock > 0): ?>
    <div class="alert alert-warn" style="margin-bottom:20px">
      ⚠️ <strong>Low stock alert!</strong> <?= $myLowStock ?> of your product(s) are below minimum threshold.
      <a href="suppliers.php" style="color:#92400e;font-weight:700">View My Products →</a>
    </div>
    <?php endif; ?>

    <!-- My order summary chips -->
    <div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px">
      <div style="background:#fff;border:1.5px solid #c7d2fe;border-radius:10px;padding:12px 20px;display:flex;align-items:center;gap:10px">
        <div style="width:12px;height:12px;border-radius:50%;background:#a855f7"></div>
        <span style="font-size:.85rem;font-weight:700;color:#1e1b4b">Pending: <strong style="color:#7c3aed"><?= $myPending ?></strong></span>
      </div>
      <div style="background:#fff;border:1.5px solid #c7d2fe;border-radius:10px;padding:12px 20px;display:flex;align-items:center;gap:10px">
        <div style="width:12px;height:12px;border-radius:50%;background:#10b981"></div>
        <span style="font-size:.85rem;font-weight:700;color:#1e1b4b">Delivered: <strong style="color:#16a34a"><?= $myDelivered ?></strong></span>
      </div>
      <div style="background:#fff;border:1.5px solid #c7d2fe;border-radius:10px;padding:12px 20px;display:flex;align-items:center;gap:10px">
        <div style="width:12px;height:12px;border-radius:50%;background:#ef4444"></div>
        <span style="font-size:.85rem;font-weight:700;color:#1e1b4b">Cancelled: <strong style="color:#dc2626"><?= $myCancelled ?></strong></span>
      </div>
      <a href="orders.php" class="btn btn-primary btn-sm" style="margin-left:auto">View All My Orders →</a>
    </div>

    <!-- Charts for supplier's own data -->
    <?php if(!empty($cats)): ?>
    <div class="charts-grid">
      <div class="chart-box">
        <div class="chart-title">My Stock by Category</div>
        <div class="bar-chart">
          <?php foreach($cats as $cat): $h = ($cat['total']/$maxCat)*100; ?>
          <div class="bar-wrap">
            <div class="bar-val"><?= $cat['total'] ?></div>
            <div class="bar" style="height:<?= $h ?>px"></div>
            <div class="bar-label"><?= substr($cat['name'],0,6) ?></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
      <div class="chart-box">
        <div class="chart-title">My Order Status</div>
        <div style="display:flex;align-items:center;justify-content:center;gap:20px">
          <canvas id="donut" width="140" height="140"></canvas>
          <div>
            <?php $colors=['Pending'=>'#a855f7','Delivered'=>'#10b981','Cancelled'=>'#ef4444'];
                  foreach($statusData as $s=>$v): ?>
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;font-size:.82rem">
              <div style="width:10px;height:10px;border-radius:50%;background:<?= $colors[$s] ?>"></div>
              <?= $s ?>: <strong><?= $v ?></strong>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
    <?php endif; ?>

    <!-- My Products table -->
    <div class="card" style="margin-bottom:20px">
      <div class="card-header">
        <span class="card-title">📦 My Products (<?= $myProducts ?>)</span>
      </div>
      <table>
        <thead><tr><th>Code</th><th>Product Name</th><th>Category</th><th>Stock</th><th>Unit Price</th><th>Status</th></tr></thead>
        <tbody>
        <?php if($myProducts == 0): ?>
          <tr><td colspan="6" style="text-align:center;color:#6b7280;padding:28px">No products assigned to your account yet.</td></tr>
        <?php else: while($p=$myProductsList->fetch_assoc()): $low=$p['stock']<=$p['min_threshold']; ?>
          <tr>
            <td style="color:#6b7280;font-size:.76rem"><?= $p['product_code'] ?></td>
            <td><strong><?= htmlspecialchars($p['name']) ?></strong></td>
            <td><?= htmlspecialchars($p['cat'] ?? '—') ?></td>
            <td><?= $p['stock'] ?><?= $low?' <span style="color:#dc2626;font-size:.7rem"> ⚠ Low</span>':'' ?></td>
            <td>₹<?= number_format($p['price'],2) ?></td>
            <td><span class="tag tag-<?= $low?'low':'ok' ?>"><?= $low?'Low Stock':'In Stock' ?></span></td>
          </tr>
        <?php endwhile; endif; ?>
        </tbody>
      </table>
    </div>

    <!-- My Recent Orders -->
    <div class="card">
      <div class="card-header">
        <span class="card-title">🛒 My Recent Orders</span>
        <a href="orders.php" class="btn btn-outline btn-sm">View All →</a>
      </div>
      <table>
        <thead><tr><th>Order ID</th><th>Product</th><th>Qty</th><th>Status</th><th>Date</th></tr></thead>
        <tbody>
        <?php if($myOrders == 0): ?>
          <tr><td colspan="5" style="text-align:center;color:#6b7280;padding:28px">No orders found for your account.</td></tr>
        <?php else: while($row=$recentOrders->fetch_assoc()): $sc=strtolower($row['status']); ?>
          <tr>
            <td style="color:#4f46e5"><?= $row['order_code'] ?></td>
            <td><?= htmlspecialchars($row['product_name']) ?></td>
            <td><?= $row['quantity'] ?></td>
            <td><span class="tag tag-<?= $sc ?>"><?= $row['status'] ?></span></td>
            <td style="color:#6b7280"><?= $row['order_date'] ?></td>
          </tr>
        <?php endwhile; endif; ?>
        </tbody>
      </table>
    </div>

  <?php endif; // end role check ?>

  </div><!-- /content -->
</div><!-- /main -->

<script>
// Donut chart — works for both admin and supplier (uses their respective statusData)
const canvas = document.getElementById('donut');
if (canvas) {
  const ctx = canvas.getContext('2d');
  const data = {
    Pending:   <?= $statusData['Pending'] ?? 0 ?>,
    Delivered: <?= $statusData['Delivered'] ?? 0 ?>,
    Cancelled: <?= $statusData['Cancelled'] ?? 0 ?>
  };
  const colors = { Pending:'#a855f7', Delivered:'#10b981', Cancelled:'#ef4444' };
  const total = Object.values(data).reduce((a,b)=>a+b,0) || 1;
  let start = -Math.PI/2;
  Object.entries(data).forEach(([k,v])=>{
    const s=(v/total)*Math.PI*2;
    ctx.beginPath(); ctx.moveTo(70,70); ctx.arc(70,70,60,start,start+s);
    ctx.closePath(); ctx.fillStyle=colors[k]; ctx.fill(); start+=s;
  });
  // White centre for bright theme
  ctx.beginPath(); ctx.arc(70,70,36,0,Math.PI*2); ctx.fillStyle='#ffffff'; ctx.fill();
  ctx.fillStyle='#1e1b4b'; ctx.font='bold 14px Times New Roman,serif';
  ctx.textAlign='center'; ctx.textBaseline='middle'; ctx.fillText(total,70,70);
}
</script>
</body>
</html>