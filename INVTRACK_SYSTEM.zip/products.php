<?php
require_once 'includes/db.php';
requireLogin();
$role = $_SESSION['role'];
$canEdit = ($role === 'admin');
$msg = '';

// ─── Handle Add/Edit/Delete ───
if ($canEdit && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'add' || $action === 'edit') {
        $name     = trim($_POST['name']);
        $cat_id   = (int)$_POST['category_id'];
        $stock    = (int)$_POST['stock'];
        $price    = (float)$_POST['price'];
        $min      = (int)$_POST['min_threshold'];
        $sup_id   = (int)$_POST['supplier_id'];
        $desc     = trim($_POST['description']);

        if ($action === 'add') {
            $res = $conn->query("SELECT COUNT(*) as c FROM products");
            $cnt = $res->fetch_assoc()['c'] + 1;
            $code = 'P' . str_pad($cnt, 3, '0', STR_PAD_LEFT);
            $stmt = $conn->prepare("INSERT INTO products (product_code,name,category_id,stock,price,min_threshold,supplier_id,description) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->bind_param("ssiidiss",$code,$name,$cat_id,$stock,$price,$min,$sup_id,$desc);
            $stmt->execute();
            $msg = 'success:Product added successfully!';
        } else {
            $id = (int)$_POST['product_id'];
            $stmt = $conn->prepare("UPDATE products SET name=?,category_id=?,stock=?,price=?,min_threshold=?,supplier_id=?,description=? WHERE id=?");
            $stmt->bind_param("siiidisi",$name,$cat_id,$stock,$price,$min,$sup_id,$desc,$id);
            $stmt->execute();
            $msg = 'success:Product updated!';
        }
    } elseif ($action === 'delete') {
        $id = (int)$_POST['product_id'];
        $conn->query("DELETE FROM products WHERE id=$id");
        $msg = 'success:Product deleted.';
    }
}

// ─── Fetch ───
$search = trim($_GET['search'] ?? '');
$catF   = (int)($_GET['cat'] ?? 0);
$where  = "WHERE 1=1";
if ($search) $where .= " AND (p.name LIKE '%".mysqli_real_escape_string($conn,$search)."%' OR c.name LIKE '%".mysqli_real_escape_string($conn,$search)."%')";
if ($catF)   $where .= " AND p.category_id=$catF";

$products = $conn->query("SELECT p.*, c.name as category_name, s.company_name as supplier_name FROM products p LEFT JOIN categories c ON p.category_id=c.id LEFT JOIN suppliers s ON p.supplier_id=s.id $where ORDER BY p.id");
$categories = $conn->query("SELECT * FROM categories ORDER BY name");
$suppliers  = $conn->query("SELECT id, company_name FROM suppliers WHERE status='approved' ORDER BY company_name");

// Store categories and suppliers for the form
$cats_arr = []; $catR = $conn->query("SELECT * FROM categories ORDER BY name");
while($r=$catR->fetch_assoc()) $cats_arr[] = $r;
$sups_arr = []; $supR = $conn->query("SELECT id,company_name FROM suppliers WHERE status='approved'");
while($r=$supR->fetch_assoc()) $sups_arr[] = $r;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>InvTrack — Products</title>
<link rel="stylesheet" href="css/style.css"/>
<style>
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(79,70,229,.2);z-index:300;align-items:center;justify-content:center;backdrop-filter:blur(4px);}
.modal-overlay.open{display:flex;}
.modal{background:#ffffff;border:1.5px solid #c7d2fe;border-radius:18px;padding:32px;width:520px;max-width:95vw;max-height:90vh;overflow-y:auto;box-shadow:0 20px 60px rgba(79,70,229,.2);}
.modal-title{font-size:1.1rem;font-weight:800;font-style:italic;margin-bottom:20px;color:#4f46e5;}
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:13px;}
.modal .fg label{font-size:.7rem;text-transform:uppercase;letter-spacing:.09em;color:#4f46e5;font-weight:700;}
.modal .fg input,.modal .fg select,.modal .fg textarea{background:#f5f3ff;border:1.5px solid #c7d2fe;color:#1e1b4b;padding:10px 12px;border-radius:8px;font-family:'Times New Roman',serif;font-size:.875rem;outline:none;width:100%;}
.modal .fg input:focus,.modal .fg select:focus,.modal .fg textarea:focus{border-color:#4f46e5;box-shadow:0 0 0 3px rgba(79,70,229,.12);background:#ffffff;}
.modal .fg select option{background:#ffffff;color:#1e1b4b;}
.modal .fg textarea{resize:vertical;min-height:72px;}
.modal .form-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:20px;}
.modal .fg.full{grid-column:span 2;}
</style>
</head>
<body>
<?php include 'includes/sidebar.php'; ?>

<div id="main">
  <div class="topbar">
    <h1>Products</h1>
    <div class="topbar-badges">
      <span class="chip chip-<?= $role ?>"><?= $role==='admin'?'👑 Admin':'🏭 Supplier' ?></span>
      <span class="chip chip-live">🟢 Live</span>
    </div>
  </div>

  <div class="content">
    <?php if($msg): list($type,$text)=explode(':',$msg,2); ?>
    <div class="alert alert-<?= $type==='success'?'success':'danger' ?>"><?= htmlspecialchars($text) ?></div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header">
        <form method="GET" action="products.php" style="display:flex;gap:9px;flex-wrap:wrap;align-items:center">
          <div class="search-box">🔍<input type="text" name="search" placeholder="Search products..." value="<?= htmlspecialchars($search) ?>"/></div>
          <select name="cat" class="filter-sel" onchange="this.form.submit()">
            <option value="">All Categories</option>
            <?php foreach($cats_arr as $c): ?>
            <option value="<?= $c['id'] ?>" <?= ($catF==$c['id'])?'selected':'' ?>><?= htmlspecialchars($c['name']) ?></option>
            <?php endforeach; ?>
          </select>
          <?php if($search||$catF): ?><a href="products.php" class="btn btn-outline btn-sm">✕ Clear</a><?php endif; ?>
        </form>
        <?php if($canEdit): ?><button class="btn btn-primary" onclick="openModal()">+ Add Product</button><?php endif; ?>
      </div>
      <table>
        <thead><tr><th>Code</th><th>Name</th><th>Category</th><th>Stock</th><th>Price</th><th>Supplier</th><th>Status</th><?php if($canEdit): ?><th>Actions</th><?php endif; ?></tr></thead>
        <tbody>
        <?php while($p=$products->fetch_assoc()): $low = $p['stock'] <= $p['min_threshold']; ?>
        <tr>
          <td style="color:var(--muted);font-size:.76rem"><?= $p['product_code'] ?></td>
          <td><strong><?= htmlspecialchars($p['name']) ?></strong><?php if($p['description']): ?><br><span style="font-size:.72rem;color:var(--muted)"><?= htmlspecialchars(substr($p['description'],0,50)) ?></span><?php endif; ?></td>
          <td><?= htmlspecialchars($p['category_name'] ?? '—') ?></td>
          <td><?= $p['stock'] ?><?php if($low): ?> <span style="color:#f87171;font-size:.72rem">⚠</span><?php endif; ?></td>
          <td>₹<?= number_format($p['price'],2) ?></td>
          <td><?= htmlspecialchars($p['supplier_name'] ?? '—') ?></td>
          <td><span class="tag tag-<?= $low?'low':'ok' ?>"><?= $low?'Low Stock':'In Stock' ?></span></td>
          <?php if($canEdit): ?>
          <td>
            <button class="btn btn-outline btn-sm" onclick='openEditModal(<?= json_encode($p) ?>)'>✏</button>
            <form method="POST" style="display:inline" onsubmit="return confirm('Delete this product?')">
              <input type="hidden" name="action" value="delete"/>
              <input type="hidden" name="product_id" value="<?= $p['id'] ?>"/>
              <button type="submit" class="btn btn-danger btn-sm">🗑</button>
            </form>
          </td>
          <?php endif; ?>
        </tr>
        <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?php if($canEdit): ?>
<!-- Add/Edit Modal -->
<div class="modal-overlay" id="product-modal">
  <div class="modal">
    <div class="modal-title" id="modal-title">Add New Product</div>
    <form method="POST" action="products.php">
      <input type="hidden" name="action" id="form-action" value="add"/>
      <input type="hidden" name="product_id" id="form-pid" value=""/>
      <div class="form-grid">
        <div class="fg"><label>Product Name *</label><input type="text" name="name" id="f-name" required/></div>
        <div class="fg"><label>Category *</label><select name="category_id" id="f-cat" required><option value="">Select...</option><?php foreach($cats_arr as $c): ?><option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option><?php endforeach; ?></select></div>
        <div class="fg"><label>Stock Qty *</label><input type="number" name="stock" id="f-stock" min="0" value="0" required/></div>
        <div class="fg"><label>Unit Price (₹) *</label><input type="number" name="price" id="f-price" step="0.01" min="0" required/></div>
        <div class="fg"><label>Min Threshold</label><input type="number" name="min_threshold" id="f-min" min="0" value="10"/></div>
        <div class="fg"><label>Supplier</label><select name="supplier_id" id="f-sup"><option value="">— None —</option><?php foreach($sups_arr as $s): ?><option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['company_name']) ?></option><?php endforeach; ?></select></div>
        <div class="fg full"><label>Description</label><textarea name="description" id="f-desc"></textarea></div>
      </div>
      <div class="form-actions">
        <button type="button" class="btn btn-outline" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn btn-primary">Save Product</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(){document.getElementById('modal-title').textContent='Add New Product';document.getElementById('form-action').value='add';document.getElementById('form-pid').value='';['f-name','f-stock','f-price','f-desc'].forEach(id=>document.getElementById(id).value='');document.getElementById('f-min').value=10;document.getElementById('f-cat').value='';document.getElementById('f-sup').value='';document.getElementById('product-modal').classList.add('open');}
function openEditModal(p){document.getElementById('modal-title').textContent='Edit Product';document.getElementById('form-action').value='edit';document.getElementById('form-pid').value=p.id;document.getElementById('f-name').value=p.name;document.getElementById('f-cat').value=p.category_id;document.getElementById('f-stock').value=p.stock;document.getElementById('f-price').value=p.price;document.getElementById('f-min').value=p.min_threshold;document.getElementById('f-sup').value=p.supplier_id||'';document.getElementById('f-desc').value=p.description||'';document.getElementById('product-modal').classList.add('open');}
function closeModal(){document.getElementById('product-modal').classList.remove('open');}
document.getElementById('product-modal').addEventListener('click',e=>{if(e.target===document.getElementById('product-modal'))closeModal();});
</script>
<?php endif; ?>
</body>
</html>